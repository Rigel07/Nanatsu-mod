package com.eric.nanatsuchaos.loot;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.eric.nanatsuchaos.registry.ModItems;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import java.util.List;

/** A tiny chance to discover a Chaos Fragment inside generated loot, including exploration chests. */
public final class ChaosChestFragmentModifier extends LootModifier {
    public static final Codec<ChaosChestFragmentModifier> CODEC = RecordCodecBuilder.create(inst ->
            codecStart(inst).apply(inst, ChaosChestFragmentModifier::new));

    public ChaosChestFragmentModifier(LootItemCondition[] conditions) { super(conditions); }

    @Override
    protected List<ItemStack> doApply(List<ItemStack> generatedLoot, LootContext context) {
        // Only generated chest loot (the global modifier would otherwise fire on every block/mob loot table too).
        if (!context.getQueriedLootTableId().getPath().startsWith("chests/")) return generatedLoot;
        float roll = context.getRandom().nextFloat();
        if (roll < 0.000001F) {
            generatedLoot.add(new ItemStack(ModItems.EXCALIBUR.get()));
        } else if (roll < 0.00005F) {
            var treasures = new net.minecraftforge.registries.RegistryObject[]{ModItems.LOSTVAYNE,ModItems.RITTA,ModItems.COURECHOUSE,ModItems.HERRITT,ModItems.ALDAN,ModItems.CHASTIEFOL,ModItems.GIDEON};
            var treasure = (net.minecraftforge.registries.RegistryObject<net.minecraft.world.item.Item>)treasures[context.getRandom().nextInt(treasures.length)];
            generatedLoot.add(new ItemStack(treasure.get()));
        } else if (roll < 0.0015F) {
            generatedLoot.add(new ItemStack(ModItems.CHAOS_FRAGMENT.get()));
        } else if (roll < 0.0019F) {
            var relics = new net.minecraftforge.registries.RegistryObject[]{ModItems.COMMANDMENT_LOVE,ModItems.COMMANDMENT_TRUTH,ModItems.COMMANDMENT_FAITH,ModItems.COMMANDMENT_RETICENCE,ModItems.COMMANDMENT_PACIFISM,ModItems.COMMANDMENT_PIETY,ModItems.COMMANDMENT_PURITY,ModItems.COMMANDMENT_REPOSE,ModItems.COMMANDMENT_PATIENCE,ModItems.COMMANDMENT_SELFLESSNESS};
            var relic = (net.minecraftforge.registries.RegistryObject<net.minecraft.world.item.Item>)relics[context.getRandom().nextInt(relics.length)];
            generatedLoot.add(new ItemStack(relic.get()));
        } else if (roll < 0.00192F) {
            var graces = new net.minecraftforge.registries.RegistryObject[]{ModItems.GRACE_SUN,ModItems.GRACE_FLASH,ModItems.GRACE_OCEAN,ModItems.GRACE_TORNADO};
            var relic = (net.minecraftforge.registries.RegistryObject<net.minecraft.world.item.Item>)graces[context.getRandom().nextInt(graces.length)];
            generatedLoot.add(new ItemStack(relic.get()));
        }
        return generatedLoot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() { return CODEC; }
}
