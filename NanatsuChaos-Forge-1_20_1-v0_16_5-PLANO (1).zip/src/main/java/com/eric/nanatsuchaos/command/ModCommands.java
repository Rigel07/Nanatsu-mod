package com.eric.nanatsuchaos.command;

import com.eric.nanatsuchaos.chaos.ChaosSkill;
import com.eric.nanatsuchaos.chaos.ChaosSkillCatalog;
import com.eric.nanatsuchaos.chaos.ChaosSkillService;
import com.eric.nanatsuchaos.progression.PlayerProgression;
import com.eric.nanatsuchaos.progression.Race;
import com.eric.nanatsuchaos.entity.HawkEntity;
import com.eric.nanatsuchaos.progression.PowerAbilityService;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.core.BlockPos;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="nanatsuchaos")
public final class ModCommands {
    private ModCommands() {}
    @SubscribeEvent public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("nanatsu")
            .then(Commands.literal("race").then(Commands.argument("race", StringArgumentType.word()).executes(ctx -> chooseRace(ctx.getSource(),StringArgumentType.getString(ctx,"race")))))
            .then(Commands.literal("skills").executes(ctx -> listSkills(ctx.getSource())))
            .then(Commands.literal("cast").then(Commands.argument("skill",StringArgumentType.word()).executes(ctx -> cast(ctx.getSource(),StringArgumentType.getString(ctx,"skill")))))
            .then(Commands.literal("progress").executes(ctx -> progress(ctx.getSource())))
            .then(Commands.literal("power").then(Commands.argument("id", StringArgumentType.word()).executes(ctx -> activatePower(ctx.getSource(), StringArgumentType.getString(ctx, "id")))))
            .then(Commands.literal("cath").executes(ctx -> cathStatus(ctx.getSource())))
            .then(Commands.literal("hawk")
                .then(Commands.literal("patrol").then(Commands.argument("radius", IntegerArgumentType.integer(4, 128)).executes(ctx -> hawkPatrol(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "radius")))))
                .then(Commands.literal("follow").executes(ctx -> hawkFollow(ctx.getSource())))
                .then(Commands.literal("stay").executes(ctx -> hawkStay(ctx.getSource())))
            )
            .then(Commands.literal("catalog").executes(ctx -> catalog(ctx.getSource())))
            .then(Commands.literal("renounce")
                .then(Commands.literal("graces").executes(ctx -> renounce(ctx.getSource(), "grace")))
                .then(Commands.literal("commandments").executes(ctx -> renounce(ctx.getSource(), "commandment")))
            )
        );
    }
    private static int chooseRace(CommandSourceStack source,String raw) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p=source.getPlayerOrException(); Race race;
        try { race=Race.valueOf(raw.toUpperCase(java.util.Locale.ROOT)); }
        catch(IllegalArgumentException ex) { p.sendSystemMessage(Component.literal("Razas: human, giant, demon, fairy, goddess.").withStyle(ChatFormatting.YELLOW)); return 0; }
        if(!PlayerProgression.chooseRace(p,race)) { p.sendSystemMessage(Component.literal("Tu raza ya está fijada para este personaje.").withStyle(ChatFormatting.RED)); return 0; }
        p.sendSystemMessage(Component.literal("Raza elegida: "+race.name()+". Tu progresión queda guardada.").withStyle(ChatFormatting.GREEN));
        p.sendSystemMessage(Component.literal("Usa /nanatsu progress para consultar tu progreso.").withStyle(ChatFormatting.GRAY)); return 1;
    }
    private static int activatePower(CommandSourceStack source, String id) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = source.getPlayerOrException();
        String normalized = id.toLowerCase(java.util.Locale.ROOT);
        if (!normalized.startsWith("grace_") && !normalized.startsWith("commandment_") && !java.util.Set.of("dark_nebula","heavy_metal","human_will","sacred_tree","purification","demon_mark").contains(normalized)) {
            p.sendSystemMessage(Component.literal("Usa /nanatsu power grace_sun|grace_flash|grace_ocean|grace_tornado o /nanatsu power commandment_<id>.").withStyle(ChatFormatting.YELLOW));
            return 0;
        }
        return PowerAbilityService.activate(p, normalized) ? 1 : 0;
    }

    private static int listSkills(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p=source.getPlayerOrException(); var ids=PlayerProgression.skills(p);
        p.sendSystemMessage(Component.literal("Habilidades del Caos desbloqueadas: "+ids.size()).withStyle(ChatFormatting.LIGHT_PURPLE));
        if(ids.isEmpty()) p.sendSystemMessage(Component.literal("Necesitas acumular 50 fragmentos del Caos para desbloquear una habilidad aleatoria de nivel I.").withStyle(ChatFormatting.GRAY));
        for(String id:ids) ChaosSkillCatalog.get(id).ifPresent(s->p.sendSystemMessage(Component.literal("• "+s.name()+" ["+id+"] — "+s.mechanic()).withStyle(s.tier()==ChaosSkill.Tier.FRAGMENT?ChatFormatting.AQUA:ChatFormatting.GOLD)));
        p.sendSystemMessage(Component.literal("Para activar una habilidad: /nanatsu cast <id>").withStyle(ChatFormatting.GRAY)); return ids.size();
    }
    private static int cast(CommandSourceStack source,String id) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p=source.getPlayerOrException();
        if(ChaosSkillCatalog.get(id).isEmpty()) { p.sendSystemMessage(Component.literal("ID desconocido. Usa /nanatsu catalog.").withStyle(ChatFormatting.RED)); return 0; }
        return ChaosSkillService.cast(p,id)?1:0;
    }
    private static int progress(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p=source.getPlayerOrException();
        p.sendSystemMessage(Component.literal("══ Nanatsu Chaos ══").withStyle(ChatFormatting.GOLD));
        p.sendSystemMessage(Component.literal("Raza: "+PlayerProgression.race(p).map(Enum::name).orElse("SIN ELEGIR")));
        p.sendSystemMessage(Component.literal("Fragmentos acumulados: "+PlayerProgression.fragments(p)+" (siguiente habilidad en "+(PlayerProgression.chaosSkillCount(p)>=50 ? "límite alcanzado" : (50-(PlayerProgression.fragments(p)%50))+" fragmentos")+")"));
        p.sendSystemMessage(Component.literal("Habilidades desbloqueadas: "+PlayerProgression.skills(p).size()));
        if (PlayerProgression.race(p).orElse(null)==Race.DEMON) p.sendSystemMessage(Component.literal("Nivel demoníaco: "+PlayerProgression.demonLevel(p)+" | Experiencia: "+PlayerProgression.demonXp(p)+"/2300. Tareas: combate, minería y exploración." ).withStyle(ChatFormatting.DARK_RED));
        p.sendSystemMessage(Component.literal("Camino elegido: "+(PlayerProgression.powerAlignment(p).isBlank()?"ninguno":PlayerProgression.powerAlignment(p).equals("grace")?"Gracias":"Mandamientos")));
        p.sendSystemMessage(Component.literal("Gracias absorbidas: "+PlayerProgression.powerCount(p,"grace")+"/4 | Mandamientos: "+PlayerProgression.powerCount(p,"commandment")+"/10"));
        if(PlayerProgression.isDemonKing(p)) p.sendSystemMessage(Component.literal("Poder supremo del Rey Demonio: DESPERTADO").withStyle(ChatFormatting.DARK_RED,ChatFormatting.BOLD));
        return 1;
    }


    private static HawkEntity ownedHawk(ServerPlayer p) {
        return p.serverLevel().getEntitiesOfClass(HawkEntity.class, p.getBoundingBox().inflate(32), h -> h.isTame() && h.isOwnedBy(p))
            .stream().min(java.util.Comparator.comparingDouble(h -> h.distanceToSqr(p))).orElse(null);
    }
    private static int hawkPatrol(CommandSourceStack source, int radius) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = source.getPlayerOrException(); HawkEntity hawk = ownedHawk(p);
        if (hawk == null) { p.sendSystemMessage(Component.literal("No encuentro a tu Hawk domesticado a 32 bloques o menos.").withStyle(ChatFormatting.RED)); return 0; }
        hawk.startPatrol(p.blockPosition(), radius);
        p.sendSystemMessage(Component.literal("Hawk patrullará alrededor de esta posición en un radio de " + radius + " bloques.").withStyle(ChatFormatting.GREEN));
        return 1;
    }
    private static int hawkFollow(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = source.getPlayerOrException(); HawkEntity hawk = ownedHawk(p);
        if (hawk == null) { p.sendSystemMessage(Component.literal("No encuentro a tu Hawk domesticado a 32 bloques o menos.").withStyle(ChatFormatting.RED)); return 0; }
        hawk.stopPatrol(); hawk.setOrderedToSit(false);
        p.sendSystemMessage(Component.literal("Hawk volverá a seguirte.").withStyle(ChatFormatting.GREEN)); return 1;
    }
    private static int hawkStay(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = source.getPlayerOrException(); HawkEntity hawk = ownedHawk(p);
        if (hawk == null) { p.sendSystemMessage(Component.literal("No encuentro a tu Hawk domesticado a 32 bloques o menos.").withStyle(ChatFormatting.RED)); return 0; }
        hawk.stopPatrol(); hawk.setOrderedToSit(true);
        p.sendSystemMessage(Component.literal("Hawk se quedará aquí.").withStyle(ChatFormatting.GREEN)); return 1;
    }

    private static int cathStatus(CommandSourceStack source) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = source.getPlayerOrException();
        var data = com.eric.nanatsuchaos.world.ChaosWorldData.get(p.serverLevel());
        String state = data.isCathPalugDefeated() ? "derrotado" : data.isCathPalugSpawned() ? (data.isExcaliburFound() ? "despierto y hostil" : "en algún lugar del mundo; aún puede ser compañero") : "todavía no descubierto";
        p.sendSystemMessage(Component.literal("Estado de Cath Palug: " + state + ". La criatura solo puede generarse una vez por mundo.").withStyle(ChatFormatting.DARK_PURPLE));
        return 1;
    }
    private static int renounce(CommandSourceStack source, String category) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = source.getPlayerOrException();
        int removed = PlayerProgression.renouncePowers(p, category);
        String label = category.equals("grace") ? "las Gracias" : "los Mandamientos";
        if (removed == 0) {
            p.sendSystemMessage(Component.literal("No tienes poderes de " + label + " que renunciar.").withStyle(ChatFormatting.YELLOW));
            return 0;
        }
        p.sendSystemMessage(Component.literal("Has renunciado a " + label + ". Se han eliminado " + removed + " poder(es); ahora puedes elegir el otro camino absorbiendo una reliquia.").withStyle(ChatFormatting.GOLD));
        if (category.equals("commandment")) p.sendSystemMessage(Component.literal("El poder del Rey Demonio se ha perdido al renunciar a los Mandamientos.").withStyle(ChatFormatting.DARK_RED));
        return removed;
    }
    private static int catalog(CommandSourceStack source) {
        var player=source.getPlayer(); if(player==null) { source.sendSuccess(()->Component.literal("Catálogo: "+ChaosSkillCatalog.all().size()+" habilidades."),false); return 1; }
        player.sendSystemMessage(Component.literal("Catálogo del Caos: "+ChaosSkillCatalog.all().size()+" habilidades definidas.").withStyle(ChatFormatting.LIGHT_PURPLE));
        for(ChaosSkill.Tier tier:ChaosSkill.Tier.values()) player.sendSystemMessage(Component.literal(tier+": "+ChaosSkillCatalog.byTier(tier).size()+" habilidades"));
        player.sendSystemMessage(Component.literal("Usa /nanatsu skills para ver las desbloqueadas.").withStyle(ChatFormatting.GRAY)); return ChaosSkillCatalog.all().size();
    }
}
