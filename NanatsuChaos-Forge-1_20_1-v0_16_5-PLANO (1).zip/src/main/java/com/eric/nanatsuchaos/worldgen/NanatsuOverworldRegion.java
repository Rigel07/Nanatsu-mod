package com.eric.nanatsuchaos.worldgen;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;
import terrablender.api.Region;
import terrablender.api.RegionType;

import java.util.function.Consumer;

/** Adds Nanatsu Chaos biomes to the Overworld's climate selection through TerraBlender. */
public final class NanatsuOverworldRegion extends Region {
    private static final ResourceKey<Biome> FAIRY_FOREST = biome("fairy_forest");
    private static final ResourceKey<Biome> DEMON_REALM = biome("demon_realm");
    private static final ResourceKey<Biome> GODDESS_HIGHLANDS = biome("goddess_highlands");

    public NanatsuOverworldRegion() {
        // Low weight keeps vanilla landscapes dominant while making themed regions discoverable.
        super(new ResourceLocation("nanatsuchaos", "overworld_region"), RegionType.OVERWORLD, 3);
    }

    private static ResourceKey<Biome> biome(String path) {
        return ResourceKey.create(Registries.BIOME, new ResourceLocation("nanatsuchaos", path));
    }

    @Override
    public void addBiomes(Registry<Biome> registry,
            Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper) {
        // The six climate axes are temperature, humidity, continentalness, erosion,
        // depth and weirdness. Register both surface and floor points for reliable sampling.
        addClimate(mapper, FAIRY_FOREST,
                span(0.15F, 0.75F), span(0.20F, 1.00F), span(0.15F, 0.85F),
                span(-0.90F, 0.25F), span(-0.55F, 0.55F));
        addClimate(mapper, DEMON_REALM,
                span(0.55F, 1.00F), span(-0.95F, 0.25F), span(0.05F, 0.95F),
                span(-0.60F, 0.65F), span(0.25F, 1.00F));
        addClimate(mapper, GODDESS_HIGHLANDS,
                span(-0.55F, 0.25F), span(-0.30F, 0.65F), span(0.35F, 1.00F),
                span(-1.00F, 0.20F), span(-1.00F, -0.25F));
    }

    private static Climate.Parameter span(float min, float max) {
        return Climate.Parameter.span(min, max);
    }

    private static void addClimate(
            Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper,
            ResourceKey<Biome> biome,
            Climate.Parameter temperature,
            Climate.Parameter humidity,
            Climate.Parameter continentalness,
            Climate.Parameter erosion,
            Climate.Parameter weirdness) {
        Climate.Parameter surface = Climate.Parameter.point(0.0F);
        Climate.Parameter floor = Climate.Parameter.span(0.2F, 0.9F);
        mapper.accept(Pair.of(Climate.parameters(temperature, humidity, continentalness, erosion, surface, weirdness, 0.0F), biome));
        mapper.accept(Pair.of(Climate.parameters(temperature, humidity, continentalness, erosion, floor, weirdness, 0.0F), biome));
    }
}
