package com.eric.nanatsuchaos;

import com.eric.nanatsuchaos.registry.ModCreativeTabs;
import com.eric.nanatsuchaos.registry.ModEntities;
import com.eric.nanatsuchaos.registry.ModItems;
import com.eric.nanatsuchaos.loot.ChaosLootModifiers;
import com.eric.nanatsuchaos.worldgen.NanatsuOverworldRegion;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import terrablender.api.Regions;
import org.slf4j.Logger;

@Mod(NanatsuChaos.MOD_ID)
public class NanatsuChaos {
    public static final String MOD_ID = "nanatsuchaos";
    public static final Logger LOGGER = LogUtils.getLogger();
    public NanatsuChaos() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITY_TYPES.register(bus);
        ModCreativeTabs.TABS.register(bus);
        ChaosLootModifiers.SERIALIZERS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> Regions.register(new NanatsuOverworldRegion()));
    }
}
