package com.eric.nanatsuchaos.progression;

import com.eric.nanatsuchaos.chaos.ChaosSkill;
import com.eric.nanatsuchaos.chaos.ChaosSkillCatalog;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import java.util.*;

/** Persistent per-player progression stored in vanilla's player persistent data. */
public final class PlayerProgression {
    private static final String ROOT = "NanatsuChaos";
    private PlayerProgression() {}
    private static CompoundTag data(ServerPlayer player) {
        CompoundTag root = player.getPersistentData();
        if (!root.contains(ROOT)) root.put(ROOT, new CompoundTag());
        return root.getCompound(ROOT);
    }
    public static Optional<Race> race(ServerPlayer p) {
        CompoundTag d=data(p); if (!d.contains("race")) return Optional.empty();
        try { return Optional.of(Race.valueOf(d.getString("race"))); } catch (IllegalArgumentException ex) { return Optional.empty(); }
    }
    public static boolean chooseRace(ServerPlayer p, Race race) {
        CompoundTag d=data(p); if (d.getBoolean("race_locked")) return false;
        d.putString("race", race.name()); d.putBoolean("race_locked", true); return true;
    }
    /** Total fragments absorbed over the character's lifetime; never resets at a reward threshold. */
    public static int fragments(ServerPlayer p) { return data(p).getInt("chaos_fragments_absorbed"); }
    public static int chaosSkillCount(ServerPlayer p) {
        int count = 0;
        for (String id : skills(p)) {
            ChaosSkill.Tier tier = ChaosSkillCatalog.get(id).map(ChaosSkill::tier).orElse(null);
            if (tier == ChaosSkill.Tier.FRAGMENT) count++;
        }
        return count;
    }
    /** Absorb exactly one fragment. A unique tier-I skill is awarded only at each 50-fragment milestone. */
    public static int absorbFragment(ServerPlayer p) {
        CompoundTag d = data(p);
        int count = d.getInt("chaos_fragments_absorbed") + 1;
        d.putInt("chaos_fragments_absorbed", count);
        d.remove("last_fragment_skill");
        if (count % 50 == 0 && chaosSkillCount(p) < 50) {
            List<String> available = ChaosSkillCatalog.byTier(ChaosSkill.Tier.FRAGMENT).stream()
                .map(ChaosSkill::id).filter(id -> !hasSkill(p, id)).toList();
            if (!available.isEmpty()) {
                String id = available.get(p.getRandom().nextInt(available.size()));
                addSkill(p, id);
                d.putString("last_fragment_skill", id);
            }
        }
        return count;
    }
    public static Optional<String> lastFragmentSkill(ServerPlayer p) {
        String id = data(p).getString("last_fragment_skill");
        return id.isBlank() ? Optional.empty() : Optional.of(id);
    }
    public static boolean hasSkill(ServerPlayer p,String id) { return data(p).getCompound("skills").getBoolean(id); }
    public static boolean addSkill(ServerPlayer p,String id) { CompoundTag skills=data(p).getCompound("skills"); if(skills.getBoolean(id)) return false; skills.putBoolean(id,true); data(p).put("skills",skills); return true; }
    public static List<String> skills(ServerPlayer p) { CompoundTag s=data(p).getCompound("skills"); List<String> out=new ArrayList<>(); for(String k:s.getAllKeys()) if(s.getBoolean(k)) out.add(k); return out; }

    /** Graces and Commandments are mutually exclusive paths. A player can renounce the whole path at any time. */
    public static boolean canAbsorbPower(ServerPlayer p, String category) {
        if (!category.equals("grace") && !category.equals("commandment")) return true;
        String other = category.equals("grace") ? "commandment" : "grace";
        CompoundTag d = data(p);
        if (powerCount(p, other) > 0) return false;
        String alignment = d.getString("power_alignment");
        return alignment.isBlank() || alignment.equals(category);
    }
    public static boolean absorbPower(ServerPlayer p, String category, String id) {
        if (!canAbsorbPower(p, category)) return false;
        CompoundTag d=data(p); String key=category+"_powers"; CompoundTag powers=d.getCompound(key);
        if(powers.getBoolean(id)) return false;
        powers.putBoolean(id,true); d.put(key,powers);
        if (category.equals("grace") || category.equals("commandment")) d.putString("power_alignment", category);
        return true;
    }
    public static boolean hasPower(ServerPlayer p, String category, String id) { return data(p).getCompound(category+"_powers").getBoolean(id); }
    public static String powerAlignment(ServerPlayer p) { return data(p).getString("power_alignment"); }
    /** Renouncing removes every power in that path, allowing the other path to be chosen afterwards. */
    public static int renouncePowers(ServerPlayer p, String category) {
        if (!category.equals("grace") && !category.equals("commandment")) return 0;
        CompoundTag d=data(p); int removed=powerCount(p, category);
        d.put(category+"_powers", new CompoundTag());
        if (category.equals("commandment")) d.putBoolean("demon_king", false);
        if (powerCount(p, category.equals("grace") ? "commandment" : "grace") == 0) d.putString("power_alignment", "");
        return removed;
    }
    public static int powerCount(ServerPlayer p, String category) {
        CompoundTag powers=data(p).getCompound(category+"_powers"); int n=0; for(String k:powers.getAllKeys()) if(powers.getBoolean(k)) n++; return n;
    }
    public static void setDemonKing(ServerPlayer p) { data(p).putBoolean("demon_king",true); }
    public static boolean isDemonKing(ServerPlayer p) { return data(p).getBoolean("demon_king"); }


    public static int demonLevel(ServerPlayer p) { return Math.max(1, Math.min(3, data(p).getInt("demon_level") == 0 ? 1 : data(p).getInt("demon_level"))); }
    public static int demonXp(ServerPlayer p) { return data(p).getInt("demon_xp"); }
    public static int demonXpRequired(int level) { return level == 1 ? 500 : level == 2 ? 1800 : Integer.MAX_VALUE; }
    public static boolean hasDocumentSkill(ServerPlayer p, String id) { return data(p).getCompound("race_documents").getBoolean(id); }
    public static boolean unlockDocumentSkill(ServerPlayer p, String id) { CompoundTag d=data(p); CompoundTag docs=d.getCompound("race_documents"); if(docs.getBoolean(id)) return false; docs.putBoolean(id,true); d.put("race_documents",docs); return true; }
    public static int addDemonXp(ServerPlayer p, int amount) {
        if (race(p).orElse(null) != Race.DEMON) return 0;
        CompoundTag d=data(p); int xp=d.getInt("demon_xp")+Math.max(0,amount); int level=d.getInt("demon_level"); if(level<1) level=1;
        if(level==1 && xp>=500) { level=2; p.sendSystemMessage(Component.literal("¡Nivel demoníaco II! Desbloqueas la Marca Demoníaca. Usa /nanatsu power demon_mark para activarla.").withStyle(ChatFormatting.DARK_RED,ChatFormatting.BOLD)); }
        if(level==2 && xp>=2300) { level=3; p.sendSystemMessage(Component.literal("¡Nivel demoníaco III! La Marca Demoníaca superior ha despertado.").withStyle(ChatFormatting.DARK_RED,ChatFormatting.BOLD)); }
        d.putInt("demon_xp",xp); d.putInt("demon_level",level); return xp;
    }
    public static void demonTask(ServerPlayer p, String task, int amount) {
        CompoundTag d=data(p); String key="task_"+task; int count=d.getInt(key)+1; d.putInt(key,count);
        int reward=Math.max(1,amount); addDemonXp(p,reward);
    }

    public static void unlockCathPalugSkill(ServerPlayer p) {
        List<String> choices=ChaosSkillCatalog.byTier(ChaosSkill.Tier.CATH_PALUG).stream().map(ChaosSkill::id).filter(id->!hasSkill(p,id)).toList();
        if(choices.isEmpty()) { p.sendSystemMessage(Component.literal("Ya has desbloqueado todos los poderes de Cath Palug.").withStyle(ChatFormatting.DARK_PURPLE)); return; }
        String id=choices.get(p.getRandom().nextInt(choices.size())); addSkill(p,id);
        ChaosSkill skill=ChaosSkillCatalog.get(id).orElseThrow();
        p.sendSystemMessage(Component.literal("¡Poder de nivel III desbloqueado: "+skill.name()+"!").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
    }

    public static void unlockExcaliburSkill(ServerPlayer p) {
        List<String> choices=ChaosSkillCatalog.byTier(ChaosSkill.Tier.EXCALIBUR).stream().map(ChaosSkill::id).filter(id->!hasSkill(p,id)).toList();
        if(choices.isEmpty()) { p.sendSystemMessage(Component.literal("Ya has desbloqueado todas las habilidades exclusivas de Excalibur.").withStyle(ChatFormatting.GOLD)); return; }
        String id=choices.get(p.getRandom().nextInt(choices.size())); addSkill(p,id);
        ChaosSkill s=ChaosSkillCatalog.get(id).orElseThrow(); p.sendSystemMessage(Component.literal("¡Excalibur despierta: "+s.name()+"!").withStyle(ChatFormatting.LIGHT_PURPLE));
    }
}
