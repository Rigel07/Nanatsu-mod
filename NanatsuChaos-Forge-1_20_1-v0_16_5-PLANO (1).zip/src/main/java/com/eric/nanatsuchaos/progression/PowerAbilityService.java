package com.eric.nanatsuchaos.progression;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;
import com.eric.nanatsuchaos.progression.Race;
import java.util.List;

/** Active techniques for each absorbed Grace and Commandment. All effects are server-authoritative. */
public final class PowerAbilityService {
    private static final long COOLDOWN_TICKS = 400L;
    private static final long SUN_COOLDOWN_TICKS = 600L;
    private PowerAbilityService() {}

    public static boolean activate(ServerPlayer p, String id) {
        if (id.equals("dark_nebula") || id.equals("heavy_metal") || id.equals("human_will") || id.equals("sacred_tree") || id.equals("purification")) return activateDocumentSkill(p,id);
        if (id.equals("demon_mark")) {
            if (PlayerProgression.race(p).orElse(null) != Race.DEMON || PlayerProgression.demonLevel(p)<2) { p.sendSystemMessage(Component.literal("La Marca Demoníaca requiere raza demonio y nivel II.").withStyle(ChatFormatting.RED)); return false; }
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,1200,PlayerProgression.demonLevel(p)>=3?5:3));
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,1200,PlayerProgression.demonLevel(p)>=3?3:1));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,1200,PlayerProgression.demonLevel(p)>=3?3:1));
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,1200,PlayerProgression.demonLevel(p)>=3?2:0));
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,1200,0));
            p.serverLevel().sendParticles(ParticleTypes.SOUL_FIRE_FLAME,p.getX(),p.getY()+1,p.getZ(),100,1.2,1.3,1.2,.08);
            p.sendSystemMessage(Component.literal(PlayerProgression.demonLevel(p)>=3?"Marca Demoníaca superior activada.":"Marca Demoníaca activada.").withStyle(ChatFormatting.DARK_RED,ChatFormatting.BOLD)); return true;
        }
        String category = id.startsWith("grace_") ? "grace" : "commandment";
        String powerId = id.substring(id.indexOf('_') + 1);
        if (!PlayerProgression.hasPower(p, category, powerId)) {
            p.sendSystemMessage(Component.literal("No has absorbido ese poder, o pertenece al otro camino.").withStyle(ChatFormatting.RED));
            return false;
        }
        var root = p.getPersistentData();
        var data = root.getCompound("NanatsuChaos");
        long now = p.serverLevel().getGameTime();
        String cdKey = "power_cd_" + id;
        long until = data.getLong(cdKey);
        if (now < until) {
            p.sendSystemMessage(Component.literal("Esta técnica se está recuperando: " + ((until - now + 19) / 20) + " s.").withStyle(ChatFormatting.YELLOW));
            return false;
        }
        ServerLevel level = p.serverLevel();
        List<LivingEntity> nearby = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(9), e -> e != p && e.isAlive());
        boolean used = true;
        switch (id) {
            // Four Graces: deliberately extremely powerful and distinct.
            case "grace_sun" -> {
                for (LivingEntity e : nearby) if (e instanceof Mob) {
                    e.hurt(p.damageSources().magic(), level.isDay() ? 32 : 22);
                    e.setSecondsOnFire(12);
                    e.push(e.getX() - p.getX(), 1.25, e.getZ() - p.getZ());
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, 2));
                }
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 300, level.isDay() ? 7 : 4));
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 3));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 3));
                p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 300, 4));
                level.sendParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 1, p.getZ(), 260, 5, 3, 5, .12);
                level.sendParticles(ParticleTypes.LAVA, p.getX(), p.getY() + 1, p.getZ(), 80, 4, 2, 4, .08);
            }
            case "grace_flash" -> {
                Vec3 look = p.getLookAngle();
                double x = p.getX() + look.x * 7, y = p.getY() + Math.max(-1, look.y * 3), z = p.getZ() + look.z * 7;
                if (level.getBlockState(net.minecraft.core.BlockPos.containing(x, y, z)).isAir() && level.getBlockState(net.minecraft.core.BlockPos.containing(x, y + 1, z)).isAir()) p.teleportTo(x, y, z);
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 240, 7));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 180, 3));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 3));
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 160, 1));
                for (LivingEntity e : nearby) if (e instanceof Mob && e.distanceToSqr(p) < 25) {
                    e.hurt(p.damageSources().magic(), 10);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 4));
                }
                level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 180, 2, 2, 2, .2);
            }
            case "grace_ocean" -> {
                for (LivingEntity e : nearby) if (e instanceof Mob) {
                    e.hurt(p.damageSources().magic(), 20);
                    e.clearFire();
                    e.push((e.getX() - p.getX()) * .8, 1.15, (e.getZ() - p.getZ()) * .8);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 180, 4));
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 180, 2));
                }
                p.heal(20);
                p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 1200, 0));
                p.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 600, 2));
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 3));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 2));
                p.addEffect(new MobEffectInstance(MobEffects.CONDUIT_POWER, 600, 0));
                level.sendParticles(ParticleTypes.SPLASH, p.getX(), p.getY() + 1, p.getZ(), 240, 5, 2, 5, .3);
            }
            case "grace_tornado" -> {
                // Ultimate wind grace: an active cutting barrier surrounds the player for 15 seconds.
                data.putLong("wind_barrier_until", now + 300L);
                for (LivingEntity e : nearby) if (e instanceof Mob) {
                    Vec3 away = e.position().subtract(p.position()).normalize().scale(3.6);
                    e.push(away.x, 2.8, away.z);
                    e.hurt(p.damageSources().magic(), 24);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 3));
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, 1));
                }
                p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 800, 0));
                p.addEffect(new MobEffectInstance(MobEffects.JUMP, 500, 7));
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 400, 5));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 4));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 4));
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 2));
                level.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 360, 4, 3, 4, .28);
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, p.getX(), p.getY() + 1, p.getZ(), 80, 3, 1, 3, .15);
                level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 100, 2, 1.5, 2, .12);
            }
            // Ten Commandments: each active technique reflects its own rule/theme.
            case "commandment_love" -> { for (LivingEntity e : nearby) if (e instanceof Mob) e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 180, 2)); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 180, 2)); p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 180, 2)); }
            case "commandment_truth" -> { for (LivingEntity e : nearby) if (e instanceof Mob) { e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 400, 0)); e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1)); } level.sendParticles(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1, p.getZ(), 100, 5, 2, 5, .1); }
            case "commandment_faith" -> { for (LivingEntity e : nearby) if (e instanceof Mob) e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 120, 0)); p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0)); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 160, 1)); }
            case "commandment_reticence" -> { p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 240, 0)); p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 240, 2)); for (LivingEntity e : nearby) if (e instanceof Mob m) m.setTarget(null); level.sendParticles(ParticleTypes.SMOKE, p.getX(), p.getY() + 1, p.getZ(), 70, 1, 1, 1, .03); }
            case "commandment_pacifism" -> { for (LivingEntity e : nearby) if (e instanceof Mob) { e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 4)); e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 2)); } p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 240, 3)); }
            case "commandment_piety" -> { for (LivingEntity e : nearby) if (e instanceof Mob) { e.hurt(p.damageSources().magic(), 10); e.setSecondsOnFire(5); } p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 600, 0)); level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1, p.getZ(), 90, 3, 1, 3, .06); }
            case "commandment_purity" -> { p.removeAllEffects(); p.heal(8); for (LivingEntity e : nearby) if (e instanceof Mob && (e.getMobType() == net.minecraft.world.entity.MobType.UNDEAD)) e.hurt(p.damageSources().magic(), 14); level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 75, 1, 1, 1, .08); }
            case "commandment_repose" -> { for (LivingEntity e : nearby) if (e instanceof Mob) { e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 160, 5)); e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 160, 1)); if (e instanceof Mob m) m.setTarget(null); } p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1)); level.sendParticles(ParticleTypes.SPORE_BLOSSOM_AIR, p.getX(), p.getY() + 1, p.getZ(), 100, 4, 1, 4, .01); }
            case "commandment_patience" -> { p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 3)); p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 300, 4)); p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1)); }
            case "commandment_selflessness" -> { p.heal(6); for (LivingEntity e : nearby) if (e instanceof ServerPlayer ally && ally.getHealth() < ally.getMaxHealth()) ally.heal(12); p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1)); level.sendParticles(ParticleTypes.HEART, p.getX(), p.getY() + 1, p.getZ(), 40, 3, 1, 3, .05); }
            default -> used = false;
        }
        if (!used) { p.sendSystemMessage(Component.literal("No existe una técnica activa para ese poder.").withStyle(ChatFormatting.RED)); return false; }
        data.putLong(cdKey, now + (id.equals("grace_sun") ? SUN_COOLDOWN_TICKS : COOLDOWN_TICKS));
        root.put("NanatsuChaos", data);
        p.sendSystemMessage(Component.literal("Técnica activada: " + id.replace('_', ' ') + " — recuperación de " + (id.equals("grace_sun") ? "30" : "20") + " segundos.").withStyle(category.equals("grace") ? ChatFormatting.AQUA : ChatFormatting.DARK_PURPLE));
        return true;
    }

    private static boolean activateDocumentSkill(ServerPlayer p,String id) {
        if (!PlayerProgression.hasDocumentSkill(p,id)) { p.sendSystemMessage(Component.literal("Aún no has descifrado el documento de esta técnica.").withStyle(ChatFormatting.RED)); return false; }
        Race race=PlayerProgression.race(p).orElse(null);
        if ((id.equals("dark_nebula") || id.equals("demon_mark")) && race!=Race.DEMON || id.equals("heavy_metal") && race!=Race.GIANT || id.equals("human_will") && race!=Race.HUMAN || id.equals("sacred_tree") && race!=Race.FAIRY || id.equals("purification") && race!=Race.GODDESS) { p.sendSystemMessage(Component.literal("Tu raza no puede utilizar esta técnica.").withStyle(ChatFormatting.RED)); return false; }
        var data=p.getPersistentData().getCompound("NanatsuChaos"); long now=p.serverLevel().getGameTime();
        if(id.equals("dark_nebula")) { data.putLong("dark_nebula_until",now+300); p.sendSystemMessage(Component.literal("Nebulosa Oscura: los enemigos serán atraídos, cortados y expulsados en un ciclo continuo durante 15 segundos.").withStyle(ChatFormatting.DARK_PURPLE)); p.serverLevel().sendParticles(ParticleTypes.SQUID_INK,p.getX(),p.getY()+1,p.getZ(),100,2,1.5,2,.15); }
        else if(id.equals("heavy_metal")) { data.putLong("heavy_metal_until",now+400); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,400,4)); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,400,4)); p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,400,1)); p.serverLevel().sendParticles(ParticleTypes.CRIT,p.getX(),p.getY()+1,p.getZ(),90,1,1,1,.1); p.sendSystemMessage(Component.literal("Metal Pesado activado: defensa colosal y golpes reforzados durante 20 segundos.").withStyle(ChatFormatting.GRAY)); }
        else if(id.equals("human_will")) { p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,600,3)); p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,600,2)); p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,600,4)); }
        else if(id.equals("sacred_tree")) { p.heal(16); p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,600,2)); p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING,600,0)); for(LivingEntity e:p.serverLevel().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(10),e->e!=p && e.isAlive() && e instanceof Mob)) e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,100,2)); }
        else if(id.equals("purification")) { p.heal(12); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,400,2)); for(LivingEntity e:p.serverLevel().getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(12),e->e!=p && e.isAlive() && e instanceof Mob)) { e.hurt(p.damageSources().magic(),28); e.addEffect(new MobEffectInstance(MobEffects.GLOWING,160,0)); } p.serverLevel().sendParticles(ParticleTypes.END_ROD,p.getX(),p.getY()+1,p.getZ(),100,3,2,3,.08); }
        p.getPersistentData().put("NanatsuChaos",data); return true;
    }
}
