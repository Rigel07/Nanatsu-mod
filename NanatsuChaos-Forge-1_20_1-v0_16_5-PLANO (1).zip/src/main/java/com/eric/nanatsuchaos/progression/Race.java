package com.eric.nanatsuchaos.progression;
public enum Race { HUMAN, GIANT, DEMON, FAIRY, GODDESS }
