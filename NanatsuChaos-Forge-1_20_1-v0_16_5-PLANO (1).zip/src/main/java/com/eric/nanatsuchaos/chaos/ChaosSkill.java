package com.eric.nanatsuchaos.chaos;

/** Unique Chaos power definitions. Each entry is intended to have its own implementation, not a renamed stat boost. */
public record ChaosSkill(String id, String name, Tier tier, String mechanic) {
    public enum Tier { FRAGMENT, EXCALIBUR, CATH_PALUG }
}
