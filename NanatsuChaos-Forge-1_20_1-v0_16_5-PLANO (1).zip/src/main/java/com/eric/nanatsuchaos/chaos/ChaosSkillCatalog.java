package com.eric.nanatsuchaos.chaos;

import java.util.*;

/** Large catalogue of distinct Chaos mechanics. Implementations are deliberately not stat-reskin variants. */
public final class ChaosSkillCatalog {
    private static final Map<String, ChaosSkill> SKILLS = new LinkedHashMap<>();
    static {
        add("gravity_well", "Gravity Well", ChaosSkill.Tier.FRAGMENT, "Create a localized gravity sphere that pulls mobs and loose items inward.");
        add("phase_step", "Phase Step", ChaosSkill.Tier.FRAGMENT, "Briefly pass through solid blocks and emerge at the targeted side.");
        add("mirror_guard", "Mirror Guard", ChaosSkill.Tier.FRAGMENT, "Reflect the next projectile back toward its shooter.");
        add("echo_strike", "Echo Strike", ChaosSkill.Tier.FRAGMENT, "Repeat the last melee hit after a delay from a spectral copy.");
        add("rift_anchor", "Rift Anchor", ChaosSkill.Tier.FRAGMENT, "Place a return point and blink back to it once before it expires.");
        add("void_lantern", "Void Lantern", ChaosSkill.Tier.FRAGMENT, "Reveal invisible mobs, hidden chests and nearby dimensional tears.");
        add("storm_cage", "Storm Cage", ChaosSkill.Tier.FRAGMENT, "Trap enemies inside a rotating ring of lightning arcs.");
        add("ember_orbit", "Ember Orbit", ChaosSkill.Tier.FRAGMENT, "Summon orbiting embers that intercept incoming arrows.");
        add("tidal_ram", "Tidal Ram", ChaosSkill.Tier.FRAGMENT, "Launch a compressed water wave that knocks enemies away.");
        add("thorn_prison", "Thorn Prison", ChaosSkill.Tier.FRAGMENT, "Roots erupt and immobilize one target, then burst into leaves.");
        add("glass_rain", "Glass Rain", ChaosSkill.Tier.FRAGMENT, "Call a cone of harmless-looking crystal shards that pierce armor.");
        add("soundquake", "Soundquake", ChaosSkill.Tier.FRAGMENT, "A focused sonic pulse interrupts attacks and shatters fragile blocks.");
        add("magnet_surge", "Magnet Surge", ChaosSkill.Tier.FRAGMENT, "Pull metal-armored enemies and dropped iron equipment together.");
        add("gravity_flip", "Gravity Flip", ChaosSkill.Tier.FRAGMENT, "Invert nearby enemies briefly, suspending them before a slam.");
        add("shadow_exchange", "Shadow Exchange", ChaosSkill.Tier.FRAGMENT, "Swap places with a targeted hostile mob.");
        add("beacon_dash", "Beacon Dash", ChaosSkill.Tier.FRAGMENT, "Dash to a visible block marked with a temporary rune.");
        add("soul_compass", "Soul Compass", ChaosSkill.Tier.FRAGMENT, "Track the last hostile creature that damaged the player.");
        add("mimic_skin", "Mimic Skin", ChaosSkill.Tier.FRAGMENT, "Copy the appearance of a nearby passive mob for a short duration.");
        add("frost_bloom", "Frost Bloom", ChaosSkill.Tier.FRAGMENT, "Grow an icy flower that slows enemies entering its petals.");
        add("sun_spear", "Sun Spear", ChaosSkill.Tier.FRAGMENT, "Throw a piercing lance of sunlight that grows stronger outdoors.");
        add("moonwell", "Moonwell", ChaosSkill.Tier.FRAGMENT, "Create a small healing pool that affects allies standing inside.");
        add("chain_lightning", "Chain Lightning", ChaosSkill.Tier.FRAGMENT, "Lightning jumps between up to six distinct nearby targets.");
        add("spell_eater", "Spell Eater", ChaosSkill.Tier.FRAGMENT, "Absorb one incoming magical projectile and convert it into charge.");
        add("iron_bark", "Iron Bark", ChaosSkill.Tier.FRAGMENT, "Grow bark armor that reduces hits but prevents sprinting.");
        add("feather_fall", "Feather Fall", ChaosSkill.Tier.FRAGMENT, "Cancel fall damage and create a gust that pushes nearby enemies.");
        add("sand_maelstrom", "Sand Maelstrom", ChaosSkill.Tier.FRAGMENT, "Create a moving sand vortex that blinds and displaces foes.");
        add("crystal_clone", "Crystal Clone", ChaosSkill.Tier.FRAGMENT, "Create a fragile decoy that attracts hostile targeting.");
        add("time_shear", "Time Shear", ChaosSkill.Tier.FRAGMENT, "Slow hostile projectiles in a short forward corridor.");
        add("battle_ledger", "Battle Ledger", ChaosSkill.Tier.FRAGMENT, "Mark one enemy; damage dealt to it is recorded and released in one burst.");
        add("dream_snare", "Dream Snare", ChaosSkill.Tier.FRAGMENT, "Put a non-boss target to sleep unless it is struck.");
        add("rune_mine", "Rune Mine", ChaosSkill.Tier.FRAGMENT, "Plant an invisible rune that detonates when a hostile crosses it.");
        add("wind_bridge", "Wind Bridge", ChaosSkill.Tier.FRAGMENT, "Create temporary solid gust platforms over gaps.");
        add("bloodless_duel", "Bloodless Duel", ChaosSkill.Tier.FRAGMENT, "Challenge one target; nearby mobs briefly stop interfering.");
        add("comet_hook", "Comet Hook", ChaosSkill.Tier.FRAGMENT, "Fire a tether that pulls the player to terrain or a large creature.");
        add("living_armor", "Living Armor", ChaosSkill.Tier.FRAGMENT, "Summon spectral armor that intercepts one otherwise fatal hit, then breaks.");
        add("lantern_swarm", "Lantern Swarm", ChaosSkill.Tier.FRAGMENT, "Release tracking lights that seek and expose hidden enemies.");
        add("gravity_orbit", "Gravity Orbit", ChaosSkill.Tier.FRAGMENT, "Make loose blocks and items orbit the player before flinging outward.");
        add("faultline", "Faultline", ChaosSkill.Tier.FRAGMENT, "Send a traveling crack through the ground that erupts beneath enemies.");
        add("rain_caller", "Rain Caller", ChaosSkill.Tier.FRAGMENT, "Create a localized rain cloud that extinguishes fire and empowers water skills.");
        add("ash_rebirth", "Ash Rebirth", ChaosSkill.Tier.FRAGMENT, "On defeat, leave an ash husk and re-form a short distance away once per cooldown.");
        add("mirror_maze", "Mirror Maze", ChaosSkill.Tier.FRAGMENT, "Create decoy reflections around the caster that confuse hostile pathing.");
        add("portal_bite", "Portal Bite", ChaosSkill.Tier.FRAGMENT, "Open a tiny rift that swallows incoming arrows and spits them behind the target.");
        add("starfall", "Starfall", ChaosSkill.Tier.FRAGMENT, "Mark a patch of ground for delayed falling-star impacts.");
        add("silence_field", "Silence Field", ChaosSkill.Tier.FRAGMENT, "Prevent nearby mobs from using special ranged attacks briefly.");
        add("anchor_weight", "Anchor Weight", ChaosSkill.Tier.FRAGMENT, "Make a target too heavy to jump or be knocked back.");
        add("hollow_step", "Hollow Step", ChaosSkill.Tier.FRAGMENT, "Leave a shadow afterimage that draws attacks while you reposition.");
        add("verdant_surge", "Verdant Surge", ChaosSkill.Tier.FRAGMENT, "Instantly grow nearby saplings and vines into climbable cover.");
        add("furnace_heart", "Furnace Heart", ChaosSkill.Tier.FRAGMENT, "Store fire damage received and vent it as a directional blast.");
        add("prism_split", "Prism Split", ChaosSkill.Tier.FRAGMENT, "Split the next beam-like spell into three angled rays.");
        add("fate_thread", "Fate Thread", ChaosSkill.Tier.FRAGMENT, "Link two enemies so a portion of one target’s damage affects the other.");
        add("ward_breaker", "Ward Breaker", ChaosSkill.Tier.FRAGMENT, "Strip active magical shields from a target instead of dealing direct damage.");
        add("storm_sail", "Storm Sail", ChaosSkill.Tier.FRAGMENT, "Ride an updraft to gain controlled aerial movement for several seconds.");
        add("oath_chain", "Oath Chain", ChaosSkill.Tier.FRAGMENT, "Bind a target that attacks an ally, briefly redirecting its aggression.");
        add("memory_steal", "Memory Steal", ChaosSkill.Tier.FRAGMENT, "Copy the last ordinary attack used by a hostile mob once.");
        add("black_snow", "Black Snow", ChaosSkill.Tier.FRAGMENT, "Cover an area in dark flakes that obscure vision and mute footsteps.");
        add("healing_debt", "Healing Debt", ChaosSkill.Tier.FRAGMENT, "Heal immediately, then repay the energy cost over time by slowing movement.");
        add("quake_counter", "Quake Counter", ChaosSkill.Tier.FRAGMENT, "Brace; the next melee hit releases a circular ground shockwave.");
        add("soul_lure", "Soul Lure", ChaosSkill.Tier.FRAGMENT, "Create a decoy sound source that attracts nearby monsters.");
        add("sky_anvil", "Sky Anvil", ChaosSkill.Tier.FRAGMENT, "Drop a spectral hammer onto one marked enemy from above.");
        add("river_gate", "River Gate", ChaosSkill.Tier.FRAGMENT, "Redirect flowing water around a temporary magical barrier.");
        add("beast_whisper", "Beast Whisper", ChaosSkill.Tier.FRAGMENT, "Calm nearby neutral mobs and briefly recruit one to distract enemies.");
        add("ember_brand", "Ember Brand", ChaosSkill.Tier.FRAGMENT, "Mark a target; its next healing effect instead releases a burst of sparks.");
        add("night_window", "Night Window", ChaosSkill.Tier.FRAGMENT, "Open a dark viewport that lets the player scout a distant location.");
        add("force_palm", "Force Palm", ChaosSkill.Tier.FRAGMENT, "Deliver a short-range invisible impact that launches a target without terrain damage.");
        add("siphon_circle", "Siphon Circle", ChaosSkill.Tier.FRAGMENT, "Draw a ring that drains stamina-like ability charge from hostile mobs.");
        add("rune_recall", "Rune Recall", ChaosSkill.Tier.FRAGMENT, "Recall the last thrown non-unique weapon to the player’s hand.");
        add("frozen_moment", "Frozen Moment", ChaosSkill.Tier.FRAGMENT, "Freeze loose projectiles and falling items in a small bubble briefly.");
        add("phoenix_mark", "Phoenix Mark", ChaosSkill.Tier.FRAGMENT, "Leave a rebirth sigil at the current position that grants a one-time rescue.");
        add("lunar_tide", "Lunar Tide", ChaosSkill.Tier.FRAGMENT, "Push enemies outward in a crescent wave that changes strength with moon phase.");
        add("dream_gate", "Dream Gate", ChaosSkill.Tier.FRAGMENT, "Teleport to a sleeping bed you have personally used, with a long cooldown.");
        add("chaos_garden", "Chaos Garden", ChaosSkill.Tier.FRAGMENT, "Grow unstable flowers that each trigger a different random utility effect.");
        add("null_step", "Null Step", ChaosSkill.Tier.FRAGMENT, "Cross a short distance while ignoring webs, powder snow and slowing terrain.");
        add("storm_drill", "Storm Drill", ChaosSkill.Tier.FRAGMENT, "Spin inside a narrow wind column, damaging and lifting enemies close by.");
        add("gravity_lens", "Gravity Lens", ChaosSkill.Tier.FRAGMENT, "Bend incoming projectiles around the player for a brief window.");
        add("primal_roar", "Primal Roar", ChaosSkill.Tier.FRAGMENT, "Force ordinary hostile mobs to flee while bosses resist the fear.");
        add("crystal_archive", "Crystal Archive", ChaosSkill.Tier.FRAGMENT, "Record a block’s appearance and place a temporary illusion copy elsewhere.");
        add("chaos_suture", "Chaos Suture", ChaosSkill.Tier.FRAGMENT, "Join two nearby locations with a brief one-way passage.");
        add("dawn_battery", "Dawn Battery", ChaosSkill.Tier.FRAGMENT, "Store sunlight during the day and spend it to power another ability at night.");
        add("abyssal_step", "Abyssal Step", ChaosSkill.Tier.FRAGMENT, "Move instantly between two patches of deep shadow in view.");
        add("meteor_shell", "Meteor Shell", ChaosSkill.Tier.FRAGMENT, "Wrap the player in a falling-star shell that crashes down when landing.");
        add("wildcard", "Wildcard", ChaosSkill.Tier.FRAGMENT, "Roll one of several utility effects, never a direct damage upgrade.");
        add("excalibur_celestial_cut", "Celestial Cut", ChaosSkill.Tier.EXCALIBUR, "A sword arc that cuts through magical barriers and leaves a temporary star-shaped rift.");
        add("excalibur_kingdom_break", "Kingdom Break", ChaosSkill.Tier.EXCALIBUR, "A charged sword strike that creates a controlled line of spatial rupture.");
        add("excalibur_chaos_crown", "Chaos Crown", ChaosSkill.Tier.EXCALIBUR, "Temporarily rewrite one nearby block into a chosen basic material.");
        add("excalibur_world_seam", "World Seam", ChaosSkill.Tier.EXCALIBUR, "Open a short-lived seam that redirects a hostile attack to its origin.");
        add("cath_palug_devour", "Devourer of Laws", ChaosSkill.Tier.CATH_PALUG, "Consume one active hostile effect and turn it into a unique temporary mutation.");
        add("cath_palug_reality_paw", "Reality Paw", ChaosSkill.Tier.CATH_PALUG, "Swipe a section of space, relocating entities without damaging terrain.");
        add("cath_palug_unmake", "Unmake the Unmade", ChaosSkill.Tier.CATH_PALUG, "Suppress a boss phase ability for a short window.");
        add("cath_palug_chaos_tide", "Chaos Tide", ChaosSkill.Tier.CATH_PALUG, "Release a massive wave of unstable energy that changes terrain only in a safe radius.");
    }
    private static void add(String id, String name, ChaosSkill.Tier tier, String mechanic) {
        if (SKILLS.putIfAbsent(id, new ChaosSkill(id, name, tier, mechanic)) != null) throw new IllegalStateException("Duplicate Chaos skill: " + id);
    }
    public static Collection<ChaosSkill> all() { return Collections.unmodifiableCollection(SKILLS.values()); }
    public static Optional<ChaosSkill> get(String id) { return Optional.ofNullable(SKILLS.get(id)); }
    public static List<ChaosSkill> byTier(ChaosSkill.Tier tier) { return SKILLS.values().stream().filter(s -> s.tier() == tier).toList(); }
    private ChaosSkillCatalog() {}
}
