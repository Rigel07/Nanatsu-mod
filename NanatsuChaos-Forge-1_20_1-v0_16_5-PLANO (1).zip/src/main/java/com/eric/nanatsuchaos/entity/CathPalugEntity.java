package com.eric.nanatsuchaos.entity;

import com.eric.nanatsuchaos.item.ExcaliburItem;
import com.eric.nanatsuchaos.progression.PlayerProgression;
import com.eric.nanatsuchaos.world.ChaosWorldData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import javax.annotation.Nullable;

/** The world's sole Cath Palug: a harmless, tamable cat before Excalibur awakens Chaos. */
public class CathPalugEntity extends TamableAnimal {
    private static final EntityDataAccessor<Boolean> AWAKENED = SynchedEntityData.defineId(CathPalugEntity.class, EntityDataSerializers.BOOLEAN);
    private int awakeNoticeCooldown = 0;
    public CathPalugEntity(EntityType<? extends TamableAnimal> type, Level level) { super(type, level); }
    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 900.0).add(Attributes.MOVEMENT_SPEED, 0.34).add(Attributes.ATTACK_DAMAGE, 22.0).add(Attributes.FOLLOW_RANGE, 64.0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0).add(Attributes.ARMOR, 18.0);
    }
    @Override protected void defineSynchedData() { super.defineSynchedData(); entityData.define(AWAKENED, false); }
    public boolean isAwakened() { return entityData.get(AWAKENED); }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.25, true));
        goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.15, 5.0F, 2.0F, false));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 10.0F));
        goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }
    @Override public void tick() {
        super.tick();
        if (level() instanceof ServerLevel serverLevel) {
            boolean shouldAwaken = ChaosWorldData.get(serverLevel).isExcaliburFound();
            if (shouldAwaken && !isAwakened()) {
                entityData.set(AWAKENED, true);
                setOrderedToSit(false);
                setTame(false);
                setTarget(null);
                setHealth(getMaxHealth());
                if (awakeNoticeCooldown <= 0) {
                    serverLevel.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Cath Palug ha despertado. El Caos ha encontrado su forma verdadera…").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD), false);
                    awakeNoticeCooldown = 200;
                }
            }
            if (awakeNoticeCooldown > 0) awakeNoticeCooldown--;
            if (isAwakened()) {
                if (tickCount % 20 == 0) {
                    Player nearest = level().getNearestPlayer(this, 48.0);
                    if (nearest != null) setTarget(nearest);
                }
                if (tickCount % 40 == 0) {
                    level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(5.0), e -> e != this && !(e instanceof CathPalugEntity) && e.isAlive()).forEach(e -> {
                        if (e instanceof Player || e instanceof net.minecraft.world.entity.Mob) e.hurt(damageSources().mobAttack(this), 7.0F);
                    });
                }
            }
        }
    }
    @Override public boolean hurt(DamageSource source, float amount) {
        if (!isAwakened()) return false;
        if (level() instanceof ServerLevel sl && ChaosWorldData.get(sl).isCathPalugDefeated()) return false;
        if (source.getEntity() instanceof Player player) {
            boolean hasExcalibur = player.getMainHandItem().getItem() instanceof ExcaliburItem || player.getOffhandItem().getItem() instanceof ExcaliburItem;
            boolean hasChaos = player instanceof ServerPlayer sp && PlayerProgression.skills(sp).stream().anyMatch(id -> id.startsWith("chaos_") || id.startsWith("excalibur_") || id.startsWith("cath_"));
            if (!hasExcalibur && !hasChaos) {
                player.displayClientMessage(Component.literal("El cuerpo de Cath Palug rechaza tu ataque. Necesitas Excalibur o un poder del Caos.").withStyle(ChatFormatting.DARK_PURPLE), true);
                return false;
            }
        } else if (source.getEntity() != null) return false;
        return super.hurt(source, amount);
    }
    @Override public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && level() instanceof ServerLevel sl && isAwakened()) {
            ChaosWorldData.get(sl).setCathPalugDefeated();
            if (source.getEntity() instanceof ServerPlayer player) {
                PlayerProgression.unlockCathPalugSkill(player);
                player.sendSystemMessage(Component.literal("Has absorbido el Caos de Cath Palug. Se abre el nivel III.").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
            }
        }
    }
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!isAwakened() && !isTame() && !stack.isEmpty() && !level().isClientSide) {
            stack.shrink(1);
            if (random.nextInt(3) == 0) { tame(player); setOrderedToSit(false); player.sendSystemMessage(Component.literal("Cath Palug te ha elegido como compañero… por ahora.").withStyle(ChatFormatting.LIGHT_PURPLE)); }
            else player.sendSystemMessage(Component.literal("Cath Palug olfatea la ofrenda y se aleja con indiferencia."));
            return InteractionResult.SUCCESS;
        }
        if (!isAwakened() && isTame() && isOwnedBy(player) && !level().isClientSide) { setOrderedToSit(!isOrderedToSit()); return InteractionResult.SUCCESS; }
        if (isAwakened() && !level().isClientSide) { player.sendSystemMessage(Component.literal("El antiguo compañero ya no existe: Cath Palug solo desea devorar el Caos.").withStyle(ChatFormatting.DARK_RED)); return InteractionResult.FAIL; }
        return super.mobInteract(player, hand);
    }
    @Override public boolean isInvulnerableTo(DamageSource source) { return !isAwakened() || super.isInvulnerableTo(source); }
    @Override protected SoundEvent getAmbientSound() { return isAwakened() ? SoundEvents.ENDER_DRAGON_GROWL : SoundEvents.CAT_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return isAwakened() ? SoundEvents.ENDER_DRAGON_HURT : SoundEvents.CAT_HISS; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ENDER_DRAGON_DEATH; }
    @Override public boolean canMate(net.minecraft.world.entity.animal.Animal other) { return false; }
    @Override public boolean canBeLeashed(Player player) { return !isAwakened(); }
    @Nullable @Override public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) { return null; }
    @Override public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) { super.addAdditionalSaveData(tag); tag.putBoolean("ChaosAwakened", isAwakened()); }
    @Override public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) { super.readAdditionalSaveData(tag); entityData.set(AWAKENED, tag.getBoolean("ChaosAwakened")); }
}
