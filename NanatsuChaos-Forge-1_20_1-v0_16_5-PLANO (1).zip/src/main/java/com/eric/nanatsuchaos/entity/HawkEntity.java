package com.eric.nanatsuchaos.entity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import javax.annotation.Nullable;

/** Immortal, tameable comic-relief pig companion. */
public class HawkEntity extends TamableAnimal {
    private boolean patrolEnabled;
    private BlockPos patrolCenter = BlockPos.ZERO;
    private int patrolRadius = 16;
    private int patrolThinkTicks;
    public HawkEntity(EntityType<? extends TamableAnimal> type, Level level) { super(type, level); }
    public static AttributeSupplier.Builder createAttributes() { return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 24.0).add(Attributes.MOVEMENT_SPEED, 0.28).add(Attributes.ATTACK_DAMAGE, 3.0).add(Attributes.FOLLOW_RANGE, 32.0); }
    @Override protected void registerGoals() {
        goalSelector.addGoal(1, new FloatGoal(this)); goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.15, true));
        goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.15, 5.0f, 2.0f, false) {
            @Override public boolean canUse() { return !patrolEnabled && super.canUse(); }
            @Override public boolean canContinueToUse() { return !patrolEnabled && super.canContinueToUse(); }
        });
        goalSelector.addGoal(5, new TemptGoal(this, 1.0, Ingredient.of(Items.APPLE, Items.CARROT, Items.COOKED_PORKCHOP), false));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.85)); goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0f)); goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }
    public void startPatrol(BlockPos center, int radius) {
        this.patrolCenter = center.immutable();
        this.patrolRadius = Math.max(4, Math.min(128, radius));
        this.patrolEnabled = true;
        this.setOrderedToSit(false);
        this.getNavigation().stop();
    }
    public void stopPatrol() { this.patrolEnabled = false; this.getNavigation().stop(); }
    public boolean isPatrolling() { return patrolEnabled; }
    public int getPatrolRadius() { return patrolRadius; }
    @Override public void tick() {
        super.tick();
        if (!level().isClientSide && isTame() && patrolEnabled && !isOrderedToSit() && ++patrolThinkTicks >= 100) {
            patrolThinkTicks = 0;
            double dx = getX() - (patrolCenter.getX() + .5), dz = getZ() - (patrolCenter.getZ() + .5);
            if (dx * dx + dz * dz > (patrolRadius * patrolRadius)) {
                getNavigation().moveTo(patrolCenter.getX() + .5, patrolCenter.getY(), patrolCenter.getZ() + .5, 1.0);
            } else if (getNavigation().isDone() || random.nextInt(3) == 0) {
                double angle = random.nextDouble() * Math.PI * 2.0;
                double distance = random.nextDouble() * patrolRadius;
                int x = patrolCenter.getX() + (int)(Math.cos(angle) * distance);
                int z = patrolCenter.getZ() + (int)(Math.sin(angle) * distance);
                BlockPos target = level().getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, patrolCenter.getY(), z));
                getNavigation().moveTo(target.getX() + .5, target.getY(), target.getZ() + .5, .8);
            }
        }
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("PatrolEnabled", patrolEnabled);
        tag.putInt("PatrolX", patrolCenter.getX()); tag.putInt("PatrolY", patrolCenter.getY()); tag.putInt("PatrolZ", patrolCenter.getZ());
        tag.putInt("PatrolRadius", patrolRadius);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        patrolEnabled = tag.getBoolean("PatrolEnabled");
        patrolCenter = new BlockPos(tag.getInt("PatrolX"), tag.getInt("PatrolY"), tag.getInt("PatrolZ"));
        patrolRadius = Math.max(4, Math.min(128, tag.getInt("PatrolRadius")));
    }
    @Override public boolean hurt(DamageSource source, float amount) { return false; }
    @Override public boolean isInvulnerableTo(DamageSource source) { return true; }
    @Override public boolean canBeLeashed(Player player) { return true; }
    @Nullable @Override public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) { return null; }
    @Override public boolean isFood(ItemStack stack) { return true; } // Hawk will happily devour any offered item.
    @Override public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (isTame()) {
            if (!player.level().isClientSide && !stack.isEmpty()) { stack.shrink(1); player.swing(hand, true); return InteractionResult.SUCCESS; }
            if (!player.level().isClientSide && isOwnedBy(player)) { setOrderedToSit(!isOrderedToSit()); return InteractionResult.SUCCESS; }
        } else if (!stack.isEmpty() && !player.level().isClientSide) {
            stack.shrink(1); if (random.nextInt(3) == 0) { tame(player); setOrderedToSit(false); } return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.PIG_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.PIG_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.PIG_DEATH; }
    @Override public boolean canMate(Animal other) { return false; }
    @Override public boolean canStandOnFluid(net.minecraft.world.level.material.FluidState state) { return false; }
}
