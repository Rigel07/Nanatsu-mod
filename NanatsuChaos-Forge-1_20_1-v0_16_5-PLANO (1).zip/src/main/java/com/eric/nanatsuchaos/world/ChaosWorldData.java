package com.eric.nanatsuchaos.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** World-global flags prevent player-specific copies of major story events. */
public class ChaosWorldData extends SavedData {
    private static final String ID="nanatsuchaos_world";
    private boolean excaliburFound;
    private boolean cathPalugSpawned;
    private boolean cathPalugDefeated;
    public static ChaosWorldData get(ServerLevel level) { return level.getServer().overworld().getDataStorage().computeIfAbsent(ChaosWorldData::load, ChaosWorldData::new, ID); }
    public static ChaosWorldData load(CompoundTag tag) { ChaosWorldData d=new ChaosWorldData(); d.excaliburFound=tag.getBoolean("excalibur_found"); d.cathPalugSpawned=tag.getBoolean("cath_palug_spawned"); d.cathPalugDefeated=tag.getBoolean("cath_palug_defeated"); return d; }
    @Override public CompoundTag save(CompoundTag tag) { tag.putBoolean("excalibur_found",excaliburFound); tag.putBoolean("cath_palug_spawned",cathPalugSpawned); tag.putBoolean("cath_palug_defeated",cathPalugDefeated); return tag; }
    public boolean isExcaliburFound(){return excaliburFound;} public void setExcaliburFound(){excaliburFound=true;setDirty();}
    public boolean isCathPalugSpawned(){return cathPalugSpawned;} public void setCathPalugSpawned(){cathPalugSpawned=true;setDirty();}
    public boolean isCathPalugDefeated(){return cathPalugDefeated;} public void setCathPalugDefeated(){cathPalugDefeated=true;setDirty();}
}
