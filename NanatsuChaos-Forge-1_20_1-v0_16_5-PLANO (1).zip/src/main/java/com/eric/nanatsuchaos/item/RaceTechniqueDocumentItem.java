package com.eric.nanatsuchaos.item;

import com.eric.nanatsuchaos.progression.PlayerProgression;
import com.eric.nanatsuchaos.progression.Race;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Rare lost scroll: a left-click consumes it and permanently records its technique. */
public final class RaceTechniqueDocumentItem extends Item {
    private final String id, race, title;
    public RaceTechniqueDocumentItem(Properties props, String id, String race, String title) { super(props.stacksTo(1)); this.id=id; this.race=race; this.title=title; }
    @Override public boolean onEntitySwing(ItemStack stack, LivingEntity entity) {
        if (!(entity instanceof ServerPlayer p)) return false;
        Race chosen=PlayerProgression.race(p).orElse(null);
        if (!race.equals("any") && (chosen==null || !chosen.name().equals(race))) {
            p.sendSystemMessage(Component.literal("Este documento solo puede ser comprendido por la raza: "+race+".").withStyle(ChatFormatting.RED)); return true;
        }
        if (!PlayerProgression.unlockDocumentSkill(p,id)) {
            p.sendSystemMessage(Component.literal("Ya conoces la técnica de este documento.").withStyle(ChatFormatting.YELLOW)); return true;
        }
        stack.shrink(1);
        p.sendSystemMessage(Component.literal("¡Documento descifrado: "+title+"! Técnica desbloqueada permanentemente. Actívala con /nanatsu power "+id+".").withStyle(ChatFormatting.GOLD,ChatFormatting.BOLD));
        return true;
    }
}
