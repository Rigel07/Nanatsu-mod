package com.eric.nanatsuchaos.item;

import com.eric.nanatsuchaos.chaos.ChaosSkill;
import com.eric.nanatsuchaos.chaos.ChaosSkillCatalog;
import com.eric.nanatsuchaos.progression.PlayerProgression;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ChaosFragmentItem extends Item {
    public ChaosFragmentItem(Properties props) { super(props); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack=player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            int result=PlayerProgression.absorbFragment(sp);
            stack.shrink(1);
            if (result % 50 == 0) {
                var awarded=PlayerProgression.lastFragmentSkill(sp);
                if (awarded.isPresent()) {
                    var skill=ChaosSkillCatalog.get(awarded.get()).orElseThrow();
                    sp.sendSystemMessage(Component.literal("¡HITO DEL CAOS! Has absorbido "+result+" fragmentos y desbloqueas al azar: "+skill.name()+". (Habilidades de fragmentos: "+PlayerProgression.chaosSkillCount(sp)+"/50)").withStyle(ChatFormatting.LIGHT_PURPLE));
                } else {
                    sp.sendSystemMessage(Component.literal("Has absorbido "+result+" fragmentos. Has alcanzado el límite de 50 habilidades de nivel I o ya no quedan habilidades nuevas en el catálogo.").withStyle(ChatFormatting.GOLD));
                }
            } else {
                int remainder=result%50;
                sp.sendSystemMessage(Component.literal("Fragmento de Caos absorbido: "+result+" acumulados. Próxima habilidad de nivel I en "+(50-remainder)+" fragmentos. Habilidades de fragmentos: "+PlayerProgression.chaosSkillCount(sp)+"/50.").withStyle(ChatFormatting.AQUA));
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
