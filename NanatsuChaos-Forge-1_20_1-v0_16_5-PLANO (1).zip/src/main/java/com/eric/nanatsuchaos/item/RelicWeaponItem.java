package com.eric.nanatsuchaos.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.util.List;

/** Each Sacred Treasure has its own active right-click ability and cooldown. */
public final class RelicWeaponItem extends Item {
    private final String relicId;
    private final String relicName;
    public RelicWeaponItem(Properties props, String relicId, String relicName) {
        super(props); this.relicId = relicId; this.relicName = relicName;
    }

    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);
        if (!(player instanceof ServerPlayer sp) || !(level instanceof ServerLevel world)) return InteractionResultHolder.fail(stack);
        if (sp.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(stack);
        if (relicId.equals("lostvayne")) {
            var data=sp.getPersistentData().getCompound("NanatsuChaos"); data.putDouble("lostvayne_charge", 0.0D); sp.getPersistentData().put("NanatsuChaos",data);
            sp.startUsingItem(hand);
            spawnIllusions(world, sp);
            sp.sendSystemMessage(Component.literal("Lostvayne: mantén pulsado el botón derecho para absorber daño; suéltalo para contraatacar.").withStyle(ChatFormatting.LIGHT_PURPLE));
            return InteractionResultHolder.consume(stack);
        }
        AABB area = sp.getBoundingBox().inflate(8.0);
        List<LivingEntity> targets = world.getEntitiesOfClass(LivingEntity.class, area,
                e -> e.isAlive() && e != sp && !e.isAlliedTo(sp));
        switch (relicId) {
            case "lostvayne" -> {
                // Counter Vanish: short evasive window, then a burst around the wielder.
                sp.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 50, 0, false, true, true));
                sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1, false, true, true));
                world.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY()+1, sp.getZ(), 45, 1.2, .8, 1.2, .08);
                sp.sendSystemMessage(Component.literal("Lostvayne: Contraimagen activada.").withStyle(ChatFormatting.LIGHT_PURPLE));
                sp.getCooldowns().addCooldown(this, 20 * 18);
            }
            case "ritta" -> {
                // Cruel Sun: solar blast around the player, with a burning aftermath.
                world.sendParticles(ParticleTypes.FLAME, sp.getX(), sp.getY()+1, sp.getZ(), 100, 3, 1.2, 3, .12);
                world.sendParticles(ParticleTypes.LAVA, sp.getX(), sp.getY()+1, sp.getZ(), 35, 2.5, .8, 2.5, .02);
                for (LivingEntity target : targets) if (target.distanceToSqr(sp) <= 64) {
                    target.hurt(world.damageSources().playerAttack(sp), 12.0F);
                    target.setSecondsOnFire(6);
                    Vec3 knock = target.position().subtract(sp.position()).normalize().scale(1.15);
                    target.push(knock.x, .35, knock.z);
                }
                sp.getCooldowns().addCooldown(this, 20 * 24);
            }
            case "courechouse" -> {
                // Snatch: pull nearby enemies inward and disrupt their movement.
                world.sendParticles(ParticleTypes.SWEEP_ATTACK, sp.getX(), sp.getY()+1, sp.getZ(), 25, 2.5, .7, 2.5, .1);
                for (LivingEntity target : targets) if (target.distanceToSqr(sp) <= 144) {
                    Vec3 pull = sp.position().subtract(target.position()).normalize().scale(1.6);
                    target.push(pull.x, .28, pull.z);
                    target.hurt(world.damageSources().playerAttack(sp), 7.0F);
                    target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 1));
                }
                sp.getCooldowns().addCooldown(this, 20 * 14);
            }
            case "herritt" -> {
                // Invasion: mental interference weakens and exposes nearby foes.
                world.sendParticles(ParticleTypes.ENCHANT, sp.getX(), sp.getY()+1, sp.getZ(), 100, 4, 2, 4, .7);
                for (LivingEntity target : targets) if (target.distanceToSqr(sp) <= 256) {
                    target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 20 * 8, 1));
                    target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * 8, 0));
                    target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 20 * 4, 0));
                }
                sp.getCooldowns().addCooldown(this, 20 * 20);
            }
            case "aldan" -> {
                // Infinity: briefly suspend nearby enemies while empowering the wielder.
                world.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY()+1, sp.getZ(), 80, 3, 2, 3, .15);
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 8, 1));
                sp.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 20 * 20, 0));
                for (LivingEntity target : targets) if (target.distanceToSqr(sp) <= 100) {
                    target.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 35, 0));
                    target.hurt(world.damageSources().playerAttack(sp), 5.0F);
                }
                sp.getCooldowns().addCooldown(this, 20 * 22);
            }
            case "chastiefol" -> {
                // Guardian: restorative pollen and a protective barrier for allies.
                world.sendParticles(ParticleTypes.HAPPY_VILLAGER, sp.getX(), sp.getY()+1, sp.getZ(), 70, 4, 1.5, 4, .15);
                for (Entity entity : world.getEntities(sp, sp.getBoundingBox().inflate(10), e -> e instanceof Player || e.isAlliedTo(sp))) {
                    if (entity instanceof LivingEntity ally) {
                        ally.heal(10.0F);
                        ally.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 7, 0));
                        ally.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 20 * 5, 1));
                    }
                }
                sp.getCooldowns().addCooldown(this, 20 * 26);
            }
            case "gideon" -> {
                // Groundbreaker: a heavy seismic impact that launches and staggers foes.
                world.sendParticles(ParticleTypes.CLOUD, sp.getX(), sp.getY()+.2, sp.getZ(), 100, 4, .25, 4, .25);
                world.sendParticles(ParticleTypes.CRIT, sp.getX(), sp.getY()+1, sp.getZ(), 55, 3.5, .7, 3.5, .2);
                for (LivingEntity target : targets) if (target.distanceToSqr(sp) <= 100) {
                    target.hurt(world.damageSources().playerAttack(sp), 10.0F);
                    target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20 * 4, 2));
                    Vec3 away = target.position().subtract(sp.position()).normalize().scale(1.25);
                    target.push(away.x, .8, away.z);
                }
                sp.getCooldowns().addCooldown(this, 20 * 18);
            }
            default -> { return InteractionResultHolder.fail(stack); }
        }
        sp.swing(hand, true);
        sp.sendSystemMessage(Component.literal(relicName + " libera su técnica sagrada.").withStyle(ChatFormatting.GOLD));
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    @Override public int getUseDuration(ItemStack stack) { return relicId.equals("lostvayne") ? 72000 : 0; }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return relicId.equals("lostvayne") ? UseAnim.BLOCK : UseAnim.NONE; }
    @Override public boolean useOnRelease(ItemStack stack) { return relicId.equals("lostvayne"); }
    @Override public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (!relicId.equals("lostvayne") || level.isClientSide || !(entity instanceof ServerPlayer p) || !(level instanceof ServerLevel world)) return;
        var d=p.getPersistentData().getCompound("NanatsuChaos"); double charge=d.getDouble("lostvayne_charge"); d.putDouble("lostvayne_charge",0); p.getPersistentData().put("NanatsuChaos",d);
        Vec3 look=p.getLookAngle(); Vec3 center=p.position().add(look.scale(8));
        int hundreds=(int)Math.min(1000000D, Math.floor(charge/100D));
        double dealt=Math.max(8D, charge);
        AABB area=new AABB(center.x-4,center.y-4,center.z-4,center.x+4,center.y+4,center.z+4);
        for (LivingEntity target:world.getEntitiesOfClass(LivingEntity.class,area,e->e.isAlive() && e!=p && !e.isAlliedTo(p))) {
            target.hurt(world.damageSources().playerAttack(p),(float)Math.min(Float.MAX_VALUE,dealt));
            target.push(look.x*(1.0+Math.min(8,hundreds)*.2), .35+Math.min(4,hundreds)*.15, look.z*(1.0+Math.min(8,hundreds)*.2));
        }
        // Every 100 absorbed damage adds a destructive tier. Radius is bounded for server stability;
        // accumulated damage itself has no programmed ceiling.
        int radius=Math.min(12, 2+hundreds/2); int destroyed=0;
        if (hundreds>0) {
            for (int x=-radius;x<=radius && destroyed<500;x++) for(int z=-radius;z<=radius && destroyed<500;z++) for(int y=-2;y<=2 && destroyed<500;y++) {
                if (x*x+z*z>radius*radius) continue;
                net.minecraft.core.BlockPos pos=net.minecraft.core.BlockPos.containing(center.x+x,center.y+y,center.z+z);
                var state=world.getBlockState(pos);
                if (!state.isAir() && state.getDestroySpeed(world,pos)>=0 && !state.getBlock().getDescriptionId().contains("bedrock") && p.mayBuild()) {
                    if(world.destroyBlock(pos,false)) destroyed++;
                }
            }
            world.sendParticles(ParticleTypes.EXPLOSION_EMITTER,center.x,center.y,center.z,Math.min(30,4+hundreds),radius*.3,.8,radius*.3,.1);
        }
        world.sendParticles(ParticleTypes.SWEEP_ATTACK,center.x,center.y,center.z,Math.min(100,20+hundreds),2,1.5,2,.2);
        p.sendSystemMessage(Component.literal("Lostvayne contraataca con "+String.format(java.util.Locale.ROOT,"%.1f",charge)+" de daño absorbido ("+hundreds+" cargas de 100). Terreno destruido: "+destroyed+" bloques.").withStyle(ChatFormatting.LIGHT_PURPLE));
        p.getCooldowns().addCooldown(this,100);
    }
    private void spawnIllusions(ServerLevel world, ServerPlayer owner) {
        if (!relicId.equals("lostvayne")) return;
        for(int i=0;i<3;i++) {
            Zombie clone=new Zombie(net.minecraft.world.entity.EntityType.ZOMBIE,world);
            double angle=(Math.PI*2*i/3.0); clone.moveTo(owner.getX()+Math.cos(angle)*2,owner.getY(),owner.getZ()+Math.sin(angle)*2,owner.getYRot(),0);
            clone.setCustomName(Component.literal("Ilusión de "+owner.getName().getString())); clone.setCustomNameVisible(false); clone.setBaby(false); clone.setSilent(true);
            clone.getPersistentData().putBoolean("NanatsuLostvayneIllusion",true); clone.getPersistentData().putUUID("NanatsuOwner",owner.getUUID());
            clone.setItemSlot(EquipmentSlot.MAINHAND,owner.getMainHandItem().copy());
            clone.setItemSlot(EquipmentSlot.HEAD,owner.getItemBySlot(EquipmentSlot.HEAD).copy()); clone.setItemSlot(EquipmentSlot.CHEST,owner.getItemBySlot(EquipmentSlot.CHEST).copy()); clone.setItemSlot(EquipmentSlot.LEGS,owner.getItemBySlot(EquipmentSlot.LEGS).copy()); clone.setItemSlot(EquipmentSlot.FEET,owner.getItemBySlot(EquipmentSlot.FEET).copy());
            LivingEntity target=world.getEntitiesOfClass(LivingEntity.class,owner.getBoundingBox().inflate(12),e->e!=owner && e.isAlive() && e instanceof Mob && !(e instanceof Zombie z && z.getPersistentData().getBoolean("NanatsuLostvayneIllusion"))).stream().findFirst().orElse(null);
            if(target instanceof Mob m) clone.setTarget(m);
            world.addFreshEntity(clone); world.sendParticles(ParticleTypes.POOF,clone.getX(),clone.getY()+1,clone.getZ(),12,.4,.8,.4,.04);
        }
    }
}
