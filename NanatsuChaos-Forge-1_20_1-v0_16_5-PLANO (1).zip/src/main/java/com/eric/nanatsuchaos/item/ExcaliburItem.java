package com.eric.nanatsuchaos.item;

import com.eric.nanatsuchaos.progression.PlayerProgression;
import com.eric.nanatsuchaos.world.ChaosWorldData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Legendary weapon. The world event is triggered once when the first copy is picked up. */
public class ExcaliburItem extends Item {
    public ExcaliburItem(Properties props) { super(props); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack=player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            ChaosWorldData data=ChaosWorldData.get(sp.serverLevel());
            if (!data.isExcaliburFound()) {
                data.setExcaliburFound();
                PlayerProgression.unlockExcaliburSkill(sp);
                sp.sendSystemMessage(Component.literal("El Caos reconoce a Excalibur. Algo antiguo despierta en Britannia…").withStyle(ChatFormatting.DARK_PURPLE));
            } else {
                sp.sendSystemMessage(Component.literal("Excalibur vibra con energía del Caos. Usa /nanatsu skills para consultar tus poderes.").withStyle(ChatFormatting.LIGHT_PURPLE));
            }
            stack.hurtAndBreak(1,sp, p->p.broadcastBreakEvent(hand));
        }
        return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
    }
}
