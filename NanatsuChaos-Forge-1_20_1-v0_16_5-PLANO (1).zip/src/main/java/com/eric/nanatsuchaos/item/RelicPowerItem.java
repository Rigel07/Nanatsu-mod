package com.eric.nanatsuchaos.item;

import com.eric.nanatsuchaos.progression.PlayerProgression;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** A collectible Grace or Commandment that is absorbed by right-clicking. */
public final class RelicPowerItem extends Item {
    private final String category;
    private final String powerId;
    private final String displayName;
    public RelicPowerItem(Properties properties, String category, String powerId, String displayName) {
        super(properties.stacksTo(1)); this.category=category; this.powerId=powerId; this.displayName=displayName;
    }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack=player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            if (!PlayerProgression.canAbsorbPower(sp, category)) {
                String other = category.equals("grace") ? "Mandamientos" : "Gracias";
                sp.sendSystemMessage(Component.literal("No puedes absorber "+displayName+" porque ya has elegido el camino de los "+other+". Renuncia primero con /nanatsu renounce "+(category.equals("grace") ? "commandments" : "graces")+".").withStyle(ChatFormatting.RED));
                return InteractionResultHolder.fail(stack);
            }
            boolean added = PlayerProgression.absorbPower(sp, category, powerId);
            if (!added) {
                sp.sendSystemMessage(Component.literal("Ya has absorbido este poder: "+displayName+".").withStyle(ChatFormatting.RED));
                return InteractionResultHolder.fail(stack);
            }
            sp.sendSystemMessage(Component.literal("¡Has absorbido "+displayName+"! "+PlayerProgression.powerCount(sp, category)+" poder(es) de esta categoría.").withStyle(category.equals("grace")?ChatFormatting.AQUA:ChatFormatting.DARK_PURPLE));
            if (category.equals("commandment") && PlayerProgression.powerCount(sp,"commandment") >= 10) {
                PlayerProgression.setDemonKing(sp);
                sp.sendSystemMessage(Component.literal("¡Los Diez Mandamientos te reconocen! Has despertado el poder supremo del Rey Demonio.").withStyle(ChatFormatting.DARK_RED,ChatFormatting.BOLD));
            }
            stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
    }
    public String powerId(){return powerId;}
    public String category(){return category;}
}
