package com.eric.nanatsuchaos.registry;

import com.eric.nanatsuchaos.NanatsuChaos;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.eric.nanatsuchaos.entity.HawkEntity;
import com.eric.nanatsuchaos.entity.CathPalugEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=NanatsuChaos.MOD_ID, bus=Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, NanatsuChaos.MOD_ID);
    public static final RegistryObject<EntityType<HawkEntity>> HAWK = ENTITY_TYPES.register("hawk", () -> EntityType.Builder.of(HawkEntity::new, MobCategory.CREATURE).sized(0.9f, 0.75f).clientTrackingRange(10).build("hawk"));
    public static final RegistryObject<EntityType<CathPalugEntity>> CATH_PALUG = ENTITY_TYPES.register("cath_palug", () -> EntityType.Builder.of(CathPalugEntity::new, MobCategory.MONSTER).sized(1.25f, 1.0f).clientTrackingRange(12).fireImmune().build("cath_palug"));
    @SubscribeEvent public static void registerAttributes(EntityAttributeCreationEvent event) { event.put(HAWK.get(), HawkEntity.createAttributes().build()); event.put(CATH_PALUG.get(), CathPalugEntity.createAttributes().build()); }
    private ModEntities() {}
}
