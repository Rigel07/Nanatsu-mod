package com.eric.nanatsuchaos.registry;

import com.eric.nanatsuchaos.NanatsuChaos;
import com.eric.nanatsuchaos.item.ChaosFragmentItem;
import com.eric.nanatsuchaos.item.ExcaliburItem;
import com.eric.nanatsuchaos.item.RelicPowerItem;
import com.eric.nanatsuchaos.item.RelicWeaponItem;
import com.eric.nanatsuchaos.item.RaceTechniqueDocumentItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, NanatsuChaos.MOD_ID);
    public static final RegistryObject<Item> CHAOS_FRAGMENT = ITEMS.register("chaos_fragment", () -> new ChaosFragmentItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> EXCALIBUR = ITEMS.register("excalibur", () -> new ExcaliburItem(new Item.Properties().stacksTo(1).fireResistant().durability(4096)));
    public static final RegistryObject<Item> LOSTVAYNE = ITEMS.register("lostvayne", () -> new RelicWeaponItem(new Item.Properties().stacksTo(1).durability(2500), "lostvayne", "Lostvayne"));
    public static final RegistryObject<Item> RITTA = ITEMS.register("ritta", () -> new RelicWeaponItem(new Item.Properties().stacksTo(1).durability(3000), "ritta", "Rita"));
    public static final RegistryObject<Item> COURECHOUSE = ITEMS.register("courechouse", () -> new RelicWeaponItem(new Item.Properties().stacksTo(1).durability(2200), "courechouse", "Courechouse"));
    public static final RegistryObject<Item> HERRITT = ITEMS.register("herritt", () -> new RelicWeaponItem(new Item.Properties().stacksTo(1).durability(2200), "herritt", "Herritt"));
    public static final RegistryObject<Item> ALDAN = ITEMS.register("aldan", () -> new RelicWeaponItem(new Item.Properties().stacksTo(1).durability(1800), "aldan", "Aldan"));
    public static final RegistryObject<Item> CHASTIEFOL = ITEMS.register("chastiefol", () -> new RelicWeaponItem(new Item.Properties().stacksTo(1).durability(2800), "chastiefol", "Chastiefol"));
    public static final RegistryObject<Item> GIDEON = ITEMS.register("gideon", () -> new RelicWeaponItem(new Item.Properties().stacksTo(1).durability(3200), "gideon", "Gideon"));
    public static final RegistryObject<Item> DEMON_MARK = ITEMS.register("demon_mark", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> COMMANDMENT_LOVE = ITEMS.register("commandment_love", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "love", "Mandamiento de Love"));
    public static final RegistryObject<Item> COMMANDMENT_TRUTH = ITEMS.register("commandment_truth", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "truth", "Mandamiento de Truth"));
    public static final RegistryObject<Item> COMMANDMENT_FAITH = ITEMS.register("commandment_faith", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "faith", "Mandamiento de Faith"));
    public static final RegistryObject<Item> COMMANDMENT_RETICENCE = ITEMS.register("commandment_reticence", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "reticence", "Mandamiento de Reticence"));
    public static final RegistryObject<Item> COMMANDMENT_PACIFISM = ITEMS.register("commandment_pacifism", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "pacifism", "Mandamiento de Pacifism"));
    public static final RegistryObject<Item> COMMANDMENT_PIETY = ITEMS.register("commandment_piety", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "piety", "Mandamiento de Piety"));
    public static final RegistryObject<Item> COMMANDMENT_PURITY = ITEMS.register("commandment_purity", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "purity", "Mandamiento de Purity"));
    public static final RegistryObject<Item> COMMANDMENT_REPOSE = ITEMS.register("commandment_repose", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "repose", "Mandamiento de Repose"));
    public static final RegistryObject<Item> COMMANDMENT_PATIENCE = ITEMS.register("commandment_patience", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "patience", "Mandamiento de Patience"));
    public static final RegistryObject<Item> COMMANDMENT_SELFLESSNESS = ITEMS.register("commandment_selflessness", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "commandment", "selflessness", "Mandamiento de Selflessness"));
    public static final RegistryObject<Item> GRACE_SUN = ITEMS.register("grace_sun", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "grace", "sun", "Gracia: Sol"));
    public static final RegistryObject<Item> GRACE_FLASH = ITEMS.register("grace_flash", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "grace", "flash", "Gracia: Brillo"));
    public static final RegistryObject<Item> GRACE_OCEAN = ITEMS.register("grace_ocean", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "grace", "ocean", "Gracia: Océano"));
    public static final RegistryObject<Item> GRACE_TORNADO = ITEMS.register("grace_tornado", () -> new RelicPowerItem(new Item.Properties().fireResistant(), "grace", "tornado", "Gracia: Viento"));

    public static final RegistryObject<Item> DOC_DARK_NEBULA = ITEMS.register("document_dark_nebula", () -> new RaceTechniqueDocumentItem(new Item.Properties().fireResistant(), "dark_nebula", "DEMON", "Nebulosa Oscura"));
    public static final RegistryObject<Item> DOC_HEAVY_METAL = ITEMS.register("document_heavy_metal", () -> new RaceTechniqueDocumentItem(new Item.Properties().fireResistant(), "heavy_metal", "GIANT", "Metal Pesado"));
    public static final RegistryObject<Item> DOC_HUMAN_WILL = ITEMS.register("document_human_will", () -> new RaceTechniqueDocumentItem(new Item.Properties(), "human_will", "HUMAN", "Voluntad Indomable"));
    public static final RegistryObject<Item> DOC_FAIRY_SACRED_TREE = ITEMS.register("document_sacred_tree", () -> new RaceTechniqueDocumentItem(new Item.Properties(), "sacred_tree", "FAIRY", "Dominio del Árbol Sagrado"));
    public static final RegistryObject<Item> DOC_GODDESS_PURIFICATION = ITEMS.register("document_purification", () -> new RaceTechniqueDocumentItem(new Item.Properties().fireResistant(), "purification", "GODDESS", "Luz Purificadora"));
    public static final RegistryObject<Item> HAWK_SPAWN_EGG = ITEMS.register("hawk_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.HAWK, 0xE8C8B5, 0xD95B4B, new Item.Properties()));
    private ModItems() {}
}
