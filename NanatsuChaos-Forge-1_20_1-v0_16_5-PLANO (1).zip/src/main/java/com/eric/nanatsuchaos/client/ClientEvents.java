package com.eric.nanatsuchaos.client;

import com.eric.nanatsuchaos.NanatsuChaos;
import com.eric.nanatsuchaos.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=NanatsuChaos.MOD_ID, bus=Mod.EventBusSubscriber.Bus.MOD, value=Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}
    @SubscribeEvent public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) { event.registerEntityRenderer(ModEntities.HAWK.get(), HawkRenderer::new); event.registerEntityRenderer(ModEntities.CATH_PALUG.get(), CathPalugRenderer::new); }
}
