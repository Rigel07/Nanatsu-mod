package com.eric.nanatsuchaos.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Lightweight client screen; the server remains authoritative and locks the first selected race. */
public final class RaceSelectionScreen extends Screen {
    public RaceSelectionScreen() { super(Component.literal("Elige tu raza")); }

    @Override protected void init() {
        int left = this.width / 2 - 100;
        int top = this.height / 2 - 70;
        addRenderableWidget(Button.builder(Component.literal("Humano — versátil"), b -> choose("human")).bounds(left, top, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Gigante — fuerza y resistencia"), b -> choose("giant")).bounds(left, top + 25, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Demonio — poder oscuro"), b -> choose("demon")).bounds(left, top + 50, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Hada — agilidad y vuelo mágico"), b -> choose("fairy")).bounds(left, top + 75, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Diosa — luz y regeneración"), b -> choose("goddess")).bounds(left, top + 100, 200, 20).build());
    }

    private void choose(String race) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.connection != null) {
            mc.player.connection.sendCommand("nanatsu race " + race);
        }
        onClose();
    }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.drawCenteredString(font, Component.literal("NANATSU CHAOS"), width / 2, height / 2 - 100, 0xF4D47C);
        graphics.drawCenteredString(font, Component.literal("Tu primera elección será permanente"), width / 2, height / 2 - 86, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override public boolean isPauseScreen() { return false; }
}
