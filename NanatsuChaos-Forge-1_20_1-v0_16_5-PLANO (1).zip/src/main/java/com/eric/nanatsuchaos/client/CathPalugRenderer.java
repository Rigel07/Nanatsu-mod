package com.eric.nanatsuchaos.client;

import com.eric.nanatsuchaos.entity.CathPalugEntity;
import net.minecraft.client.model.PigModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Pig-shaped placeholder model: cute before awakening, with vanilla ender-dragon sound cues after. */
public class CathPalugRenderer extends MobRenderer<CathPalugEntity, PigModel<CathPalugEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("minecraft", "textures/entity/cat/tabby.png");
    private static final ResourceLocation AWAKENED_TEXTURE = new ResourceLocation("minecraft", "textures/entity/enderdragon/dragon.png");
    public CathPalugRenderer(EntityRendererProvider.Context context) { super(context, new PigModel<>(context.bakeLayer(ModelLayers.PIG)), 0.6f); }
    @Override public ResourceLocation getTextureLocation(CathPalugEntity entity) { return entity.isAwakened() ? AWAKENED_TEXTURE : TEXTURE; }
}
