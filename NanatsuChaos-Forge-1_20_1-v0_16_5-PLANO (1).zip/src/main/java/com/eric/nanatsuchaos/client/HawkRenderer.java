package com.eric.nanatsuchaos.client;

import com.eric.nanatsuchaos.entity.HawkEntity;
import net.minecraft.client.model.PigModel;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.resources.ResourceLocation;

/** Uses Minecraft's pig model as a reliable placeholder until the custom Hawk model is added. */
public class HawkRenderer extends MobRenderer<HawkEntity, PigModel<HawkEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("minecraft", "textures/entity/pig/pig.png");
    public HawkRenderer(EntityRendererProvider.Context context) { super(context, new PigModel<>(context.bakeLayer(ModelLayers.PIG)), 0.45f); }
    @Override public ResourceLocation getTextureLocation(HawkEntity entity) { return TEXTURE; }
}
