package com.eric.nanatsuchaos.client;

import com.eric.nanatsuchaos.NanatsuChaos;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = NanatsuChaos.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class ClientKeybinds {
    public static final KeyMapping OPEN_RACE = new KeyMapping("key.nanatsuchaos.open_race", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.nanatsuchaos");
    private ClientKeybinds() {}
    @SubscribeEvent public static void register(RegisterKeyMappingsEvent event) { event.register(OPEN_RACE); }
}
