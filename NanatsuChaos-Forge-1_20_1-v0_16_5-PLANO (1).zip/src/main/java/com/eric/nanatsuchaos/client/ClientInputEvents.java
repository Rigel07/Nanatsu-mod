package com.eric.nanatsuchaos.client;

import com.eric.nanatsuchaos.NanatsuChaos;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = NanatsuChaos.MOD_ID, value = Dist.CLIENT)
public final class ClientInputEvents {
    private ClientInputEvents() {}
    @SubscribeEvent public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (ClientKeybinds.OPEN_RACE.consumeClick()) {
            if (mc.screen == null && mc.player != null) mc.setScreen(new RaceSelectionScreen());
        }
    }
}
