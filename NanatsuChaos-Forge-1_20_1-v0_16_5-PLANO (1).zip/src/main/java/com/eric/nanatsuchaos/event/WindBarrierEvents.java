package com.eric.nanatsuchaos.event;

import com.eric.nanatsuchaos.progression.PlayerProgression;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server-side cutting wind barrier for the Wind Grace. */
@Mod.EventBusSubscriber(modid = "nanatsuchaos")
public final class WindBarrierEvents {
    private WindBarrierEvents() {}

    private static boolean active(ServerPlayer player) {
        var data = player.getPersistentData().getCompound("NanatsuChaos");
        return PlayerProgression.hasPower(player, "grace", "tornado")
                && data.getLong("wind_barrier_until") > player.serverLevel().getGameTime();
    }

    @SubscribeEvent
    public static void blockAndCut(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !active(player)) return;
        event.setCanceled(true); // blocks melee, projectiles and other incoming attack damage
        if (player.tickCount % 4 == 0) {
            ServerLevel level = player.serverLevel();
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, player.getX(), player.getY() + 1,
                    player.getZ(), 10, 1.15, 0.8, 1.15, 0.02);
        }
        if (event.getSource().getEntity() instanceof LivingEntity attacker && attacker != player
                && attacker.isAlive() && player.tickCount % 4 == 0) {
            attacker.hurt(player.damageSources().magic(), 10.0F);
            Vec3 away = attacker.position().subtract(player.position()).normalize().scale(1.2);
            attacker.push(away.x, 0.45, away.z);
            levelParticles(player, attacker);
        }
    }

    @SubscribeEvent
    public static void barrierPulse(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)
                || !active(player)) return;
        ServerLevel level = player.serverLevel();
        long now = level.getGameTime();
        if (player.tickCount % 3 == 0) {
            // A visible ring of wind continuously surrounds the player.
            for (int i = 0; i < 16; i++) {
                double angle = (Math.PI * 2.0 * i / 16.0) + now * 0.12;
                double x = player.getX() + Math.cos(angle) * 1.45;
                double z = player.getZ() + Math.sin(angle) * 1.45;
                level.sendParticles(ParticleTypes.CLOUD, x, player.getY() + 0.65, z, 1, 0.03, 0.5, 0.03, 0.01);
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, x, player.getY() + 1.1, z, 1, 0, 0.2, 0, 0.0);
            }
        }
        // Every half-second the barrier slices hostile mobs that get too close.
        if (player.tickCount % 10 == 0) {
            for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class,
                    player.getBoundingBox().inflate(2.25), e -> e != player && e.isAlive() && e instanceof Mob)) {
                target.hurt(player.damageSources().magic(), 8.0F);
                Vec3 away = target.position().subtract(player.position()).normalize().scale(0.9);
                target.push(away.x, 0.3, away.z);
                level.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY() + target.getBbHeight() * 0.5,
                        target.getZ(), 5, 0.35, 0.35, 0.35, 0.02);
            }
        }
    }

    private static void levelParticles(ServerPlayer player, LivingEntity attacker) {
        player.serverLevel().sendParticles(ParticleTypes.SWEEP_ATTACK,
                attacker.getX(), attacker.getY() + attacker.getBbHeight() * 0.5, attacker.getZ(),
                12, 0.4, 0.4, 0.4, 0.03);
    }
}
