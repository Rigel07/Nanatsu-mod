package com.eric.nanatsuchaos.event;

import com.eric.nanatsuchaos.progression.PlayerProgression;
import com.eric.nanatsuchaos.progression.Race;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="nanatsuchaos")
public final class ProgressionEvents {
    private ProgressionEvents() {}
    @SubscribeEvent public static void login(PlayerEvent.PlayerLoggedInEvent event) {
        if(event.getEntity() instanceof ServerPlayer p && PlayerProgression.race(p).isEmpty()) {
            p.sendSystemMessage(Component.literal("Bienvenido a Britannia. Elige tu raza con /nanatsu race human|giant|demon|fairy|goddess.").withStyle(ChatFormatting.GOLD));
        }
    }
    @SubscribeEvent public static void tick(TickEvent.PlayerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || !(event.player instanceof ServerPlayer p)) return;
        if (p.tickCount%200==0 && PlayerProgression.race(p).orElse(null)==Race.DEMON && p.getDeltaMovement().horizontalDistanceSqr()>.01) PlayerProgression.demonTask(p,"exploration",2);
        if (p.tickCount%40!=0) return;
        if (PlayerProgression.race(p).orElse(null)==Race.DEMON) {
            int level=PlayerProgression.demonLevel(p);
            if(level>=2) { p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,100,2,true,false)); p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,100,1,true,false)); }
            if(level>=3) { p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,2,true,false)); p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,100,1,true,false)); }
        }
        var nbt=p.getPersistentData().getCompound("NanatsuChaos"); long now=p.serverLevel().getGameTime();
        if(nbt.getLong("dark_nebula_until")>now && p.tickCount%4==0) {
            var area=p.getBoundingBox().inflate(14); var foes=p.serverLevel().getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,area,e->e!=p && e.isAlive() && !e.isAlliedTo(p));
            for(var foe:foes) { net.minecraft.world.phys.Vec3 pull=p.position().subtract(foe.position()).normalize().scale(1.25); foe.push(pull.x,pull.y+.12,pull.z); foe.hurt(p.damageSources().magic(),3.5F); foe.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,10,5)); if(p.tickCount%20==0) { var away=foe.position().subtract(p.position()).normalize().scale(2.5); foe.push(away.x,.45,away.z); } }
            p.serverLevel().sendParticles(net.minecraft.core.particles.ParticleTypes.SQUID_INK,p.getX(),p.getY()+1,p.getZ(),12,2,1,2,.03);
        }
        PlayerProgression.race(p).ifPresent(race -> {
            switch(race) {
                case HUMAN -> { p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED,80,0,true,false)); }
                case GIANT -> { p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,80,0,true,false)); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,80,0,true,false)); }
                case DEMON -> { p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,80,0,true,false)); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,80,1,true,false)); }
                case FAIRY -> { p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING,80,0,true,false)); p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,80,1,true,false)); }
                case GODDESS -> { p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,80,0,true,false)); p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,80,0,true,false)); }
            }
        });
        // Four Graces: each is balanced as a legendary path, not a minor buff.
        // Flash, Ocean and Wind target a 3-Commandment combat tier; Sunshine targets 8.
        if (PlayerProgression.hasPower(p,"grace","sun")) {
            // Sunshine is intentionally absurdly strong by day, but remains dangerous at night.
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,100,0,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED,100,4,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,2,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,100,3,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,100,2,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,100,p.level().isDay()?7:4,true,false));
            if (p.level().isDay()) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,100,2,true,false));
                p.addEffect(new MobEffectInstance(MobEffects.JUMP,100,2,true,false));
            }
        }
        if (PlayerProgression.hasPower(p,"grace","flash")) {
            // Extreme mobility, rapid mining, and strong but not absolute survivability.
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,100,5,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED,100,4,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.JUMP,100,4,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,300,0,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,2,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,100,2,true,false));
        }
        if (PlayerProgression.hasPower(p,"grace","ocean")) {
            p.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING,120,0,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE,120,1,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,100,2,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,1,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.CONDUIT_POWER,120,0,true,false));
            if (p.isInWaterOrRain()) {
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,100,5,true,false));
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,3,true,false));
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,100,4,true,false));
            }
        }
        if (PlayerProgression.hasPower(p,"grace","tornado")) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,100,4,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.JUMP,100,5,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,2,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING,100,0,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,100,!p.onGround()?4:2,true,false));
            if (!p.onGround()) p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,100,1,true,false));
        }
        // Commandments are adapted into survival rules rather than cosmetic buffs.
        if (PlayerProgression.hasPower(p,"commandment","love") && p.getHealth() < p.getMaxHealth()*0.5f)
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,80,1,true,false));
        if (PlayerProgression.hasPower(p,"commandment","truth"))
            p.level().getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,p.getBoundingBox().inflate(12), e -> e != p && e.isAlive() && e instanceof net.minecraft.world.entity.monster.Monster).forEach(e -> e.addEffect(new MobEffectInstance(MobEffects.GLOWING,60,0,true,false)));
        if (PlayerProgression.hasPower(p,"commandment","faith") && !p.level().isDay())
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,80,0,true,false));
        if (PlayerProgression.hasPower(p,"commandment","reticence") && p.isCrouching())
            p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY,80,0,true,false));
        if (PlayerProgression.hasPower(p,"commandment","pacifism")) {
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,80,0,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,80,0,true,false));
        }
        if (PlayerProgression.hasPower(p,"commandment","piety"))
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,100,0,true,false));
        if (PlayerProgression.hasPower(p,"commandment","purity") && p.isInWater())
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,80,0,true,false));
        if (PlayerProgression.hasPower(p,"commandment","repose") && p.getDeltaMovement().horizontalDistanceSqr()<0.0025)
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,80,0,true,false));
        if (PlayerProgression.hasPower(p,"commandment","patience"))
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,80,0,true,false));
        if (PlayerProgression.hasPower(p,"commandment","selflessness") && p.getHealth()<p.getMaxHealth()*0.75f)
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,80,0,true,false));
        if (PlayerProgression.isDemonKing(p)) {
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,80,2,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,80,1,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.REGENERATION,80,1,true,false));
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,80,0,true,false));
        }
    }
}
