package com.eric.nanatsuchaos.event;

import com.eric.nanatsuchaos.item.ExcaliburItem;
import com.eric.nanatsuchaos.progression.PlayerProgression;
import com.eric.nanatsuchaos.world.ChaosWorldData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** The first real pickup, not merely using the sword, awakens the world's Cath Palug. */
@Mod.EventBusSubscriber(modid="nanatsuchaos")
public final class ExcaliburDiscoveryEvents {
    private ExcaliburDiscoveryEvents() {}
    @SubscribeEvent public static void onPickup(EntityItemPickupEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!(event.getItem().getItem().getItem() instanceof ExcaliburItem)) return;
        var world = ChaosWorldData.get(player.serverLevel());
        if (world.isExcaliburFound()) return;
        world.setExcaliburFound();
        PlayerProgression.unlockExcaliburSkill(player);
        player.sendSystemMessage(Component.literal("La primera Excalibur ha sido encontrada. En algún lugar de Britannia, Cath Palug despierta…").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
    }
}
