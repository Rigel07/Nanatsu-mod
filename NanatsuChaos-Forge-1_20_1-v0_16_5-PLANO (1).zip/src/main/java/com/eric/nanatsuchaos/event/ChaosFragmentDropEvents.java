package com.eric.nanatsuchaos.event;

import com.eric.nanatsuchaos.registry.ModItems;
import com.eric.nanatsuchaos.world.ChaosWorldData;
import com.eric.nanatsuchaos.progression.PlayerProgression;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Very rare world drops. Rates are intentionally low so Chaos powers remain an exploration endgame. */
@Mod.EventBusSubscriber(modid = "nanatsuchaos")
public final class ChaosFragmentDropEvents {
    private ChaosFragmentDropEvents() {}

    @SubscribeEvent
    public static void onItemPickup(PlayerEvent.ItemPickupEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getOriginalEntity().getItem().getItem() != ModItems.EXCALIBUR.get()) return;
        ChaosWorldData worldData = ChaosWorldData.get(player.serverLevel());
        if (!worldData.isExcaliburFound()) {
            worldData.setExcaliburFound();
            PlayerProgression.unlockExcaliburSkill(player);
            player.sendSystemMessage(Component.literal("La primera Excalibur del mundo ha sido encontrada. Algo antiguo despierta en Britannia…").withStyle(ChatFormatting.DARK_PURPLE,ChatFormatting.BOLD));
        }
    }

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        if (event.getEntity().level().isClientSide || !(event.getEntity().level() instanceof ServerLevel level)) return;
        // 0.65% chance per killed creature; looting slightly helps, without making farming reliable.
        int looting = event.getSource().getEntity() instanceof net.minecraft.world.entity.LivingEntity killer
                ? killer.getMainHandItem().getEnchantmentLevel(net.minecraft.world.item.enchantment.Enchantments.MOB_LOOTING) : 0;
        double chance = 0.0065 + Math.min(looting, 3) * 0.0015;
        var pos = event.getEntity().position();
        if (level.random.nextDouble() < 0.000002) {
            event.getDrops().add(new ItemEntity(level,pos.x,pos.y+0.4,pos.z,new ItemStack(ModItems.EXCALIBUR.get())));
        } else if (level.random.nextDouble() < 0.00004) {
            var treasures = new net.minecraftforge.registries.RegistryObject[]{ModItems.LOSTVAYNE,ModItems.RITTA,ModItems.COURECHOUSE,ModItems.HERRITT,ModItems.ALDAN,ModItems.CHASTIEFOL,ModItems.GIDEON};
            var treasure = (net.minecraftforge.registries.RegistryObject<net.minecraft.world.item.Item>)treasures[level.random.nextInt(treasures.length)];
            event.getDrops().add(new ItemEntity(level,pos.x,pos.y+0.4,pos.z,new ItemStack(treasure.get())));
        }
        if (level.random.nextDouble() < chance) {
            event.getDrops().add(new ItemEntity(level, pos.x, pos.y + 0.25, pos.z, new ItemStack(ModItems.CHAOS_FRAGMENT.get())));
        }
        // Commandments are rare; Graces are rarer still. A kill can only award one special relic.
        if (level.random.nextDouble() < 0.00035) {
            var relics = new net.minecraftforge.registries.RegistryObject[]{ModItems.COMMANDMENT_LOVE,ModItems.COMMANDMENT_TRUTH,ModItems.COMMANDMENT_FAITH,ModItems.COMMANDMENT_RETICENCE,ModItems.COMMANDMENT_PACIFISM,ModItems.COMMANDMENT_PIETY,ModItems.COMMANDMENT_PURITY,ModItems.COMMANDMENT_REPOSE,ModItems.COMMANDMENT_PATIENCE,ModItems.COMMANDMENT_SELFLESSNESS};
            var relic = (net.minecraftforge.registries.RegistryObject<net.minecraft.world.item.Item>)relics[level.random.nextInt(relics.length)];
            event.getDrops().add(new ItemEntity(level,pos.x,pos.y+0.35,pos.z,new ItemStack(relic.get())));
        } else if (level.random.nextDouble() < 0.00008) {
            var graces = new net.minecraftforge.registries.RegistryObject[]{ModItems.GRACE_SUN,ModItems.GRACE_FLASH,ModItems.GRACE_OCEAN,ModItems.GRACE_TORNADO};
            var relic = (net.minecraftforge.registries.RegistryObject<net.minecraft.world.item.Item>)graces[level.random.nextInt(graces.length)];
            event.getDrops().add(new ItemEntity(level,pos.x,pos.y+0.35,pos.z,new ItemStack(relic.get())));
        }
    }

    @SubscribeEvent
    public static void onBlockBroken(BlockEvent.BreakEvent event) {
        if (!(event.getPlayer() instanceof ServerPlayer player) || !(event.getLevel() instanceof ServerLevel level)) return;
        // Tiny chance from mining, with a small bonus for ores and ancient debris.
        String id = event.getState().getBlock().builtInRegistryHolder().key().location().getPath();
        boolean ore = id.contains("ore") || id.equals("ancient_debris") || id.equals("amethyst_block");
        double chance = ore ? 0.0012 : 0.00008;
        if (level.random.nextDouble() < chance) {
            var pos = event.getPos();
            level.addFreshEntity(new ItemEntity(level, pos.getX() + 0.5, pos.getY() + 0.7, pos.getZ() + 0.5,
                    new ItemStack(ModItems.CHAOS_FRAGMENT.get())));
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("Has encontrado un fragmento del Caos."), true);
        }
    }
}
