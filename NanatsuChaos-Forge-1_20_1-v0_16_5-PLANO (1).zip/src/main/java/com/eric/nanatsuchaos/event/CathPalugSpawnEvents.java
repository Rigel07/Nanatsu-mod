package com.eric.nanatsuchaos.event;

import com.eric.nanatsuchaos.entity.CathPalugEntity;
import com.eric.nanatsuchaos.registry.ModEntities;
import com.eric.nanatsuchaos.world.ChaosWorldData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Cath Palug is generated only once per world and only after the world has been explored for a while. */
@Mod.EventBusSubscriber(modid="nanatsuchaos")
public final class CathPalugSpawnEvents {
    private CathPalugSpawnEvents() {}
    @SubscribeEvent public static void playerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player) || player.tickCount % 100 != 0 || player.level().isClientSide) return;
        ServerLevel level = player.serverLevel();
        if (level.getGameTime() < 12000L) return;
        ChaosWorldData data = ChaosWorldData.get(level);
        if (data.isCathPalugSpawned() || data.isCathPalugDefeated()) return;
        // Very low probability per eligible exploration check; never teleport the boss to the player.
        if (player.getRandom().nextInt(1800) != 0) return;
        int angle = player.getRandom().nextInt(360);
        double radians = Math.toRadians(angle);
        int distance = 48 + player.getRandom().nextInt(49);
        int x = player.blockPosition().getX() + (int)(Math.cos(radians) * distance);
        int z = player.blockPosition().getZ() + (int)(Math.sin(radians) * distance);
        BlockPos surface = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, player.blockPosition().getY(), z));
        if (!level.hasChunkAt(surface) || !level.getWorldBorder().isWithinBounds(surface)) return;
        BlockState ground = level.getBlockState(surface.below());
        if (ground.isAir() || ground.is(Blocks.WATER) || ground.is(Blocks.LAVA) || !level.getBlockState(surface).getFluidState().isEmpty()) return;
        CathPalugEntity cath = ModEntities.CATH_PALUG.get().create(level);
        if (cath == null) return;
        cath.moveTo(surface.getX()+0.5, surface.getY(), surface.getZ()+0.5, player.getRandom().nextFloat()*360.0F, 0.0F);
        if (level.addFreshEntity(cath)) {
            data.setCathPalugSpawned();
            player.sendSystemMessage(net.minecraft.network.chat.Component.literal("Algo pequeño te observa entre los árboles…").withStyle(net.minecraft.ChatFormatting.LIGHT_PURPLE));
        }
    }
}
