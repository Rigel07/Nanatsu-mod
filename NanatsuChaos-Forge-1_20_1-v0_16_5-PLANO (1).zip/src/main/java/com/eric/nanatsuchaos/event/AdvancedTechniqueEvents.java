package com.eric.nanatsuchaos.event;

import com.eric.nanatsuchaos.progression.PlayerProgression;
import com.eric.nanatsuchaos.progression.Race;
import com.eric.nanatsuchaos.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="nanatsuchaos")
public final class AdvancedTechniqueEvents {
 private AdvancedTechniqueEvents() {}
 @SubscribeEvent public static void absorbDamage(LivingHurtEvent event) {
   if (!(event.getEntity() instanceof ServerPlayer p)) {
     if(event.getEntity() instanceof Zombie z && z.getPersistentData().getBoolean("NanatsuLostvayneIllusion")) { z.setHealth(0); event.setCanceled(true); z.level().broadcastEntityEvent(z,(byte)3); }
     return;
   }
   var playerData=p.getPersistentData().getCompound("NanatsuChaos");
   if(playerData.getLong("dark_nebula_until")>p.serverLevel().getGameTime()) { event.setCanceled(true); return; }
   if(p.isUsingItem() && p.getUseItem().is(ModItems.LOSTVAYNE.get())) {
     var d=p.getPersistentData().getCompound("NanatsuChaos"); double old=d.getDouble("lostvayne_charge"); d.putDouble("lostvayne_charge",old+Math.max(0.0F,event.getAmount())); p.getPersistentData().put("NanatsuChaos",d); event.setCanceled(true);
     p.serverLevel().sendParticles(net.minecraft.core.particles.ParticleTypes.ENCHANT,p.getX(),p.getY()+1,p.getZ(),8,.5,.5,.5,.1);
   }
   if (p.getPersistentData().getCompound("NanatsuChaos").getLong("heavy_metal_until")>p.serverLevel().getGameTime() && PlayerProgression.hasDocumentSkill(p,"heavy_metal")) event.setCanceled(true);
 }
 @SubscribeEvent public static void killXp(LivingDeathEvent event) {
   if(event.getSource().getEntity() instanceof ServerPlayer p && PlayerProgression.race(p).orElse(null)==Race.DEMON && event.getEntity()!=p) {
     int reward=event.getEntity() instanceof Mob ? 8 : 3; PlayerProgression.demonTask(p,"kill",reward);
     if(PlayerProgression.demonXp(p)%100<reward) p.sendSystemMessage(Component.literal("Experiencia demoníaca: "+PlayerProgression.demonXp(p)+". Combate +"+reward+" XP.").withStyle(ChatFormatting.DARK_RED));
   }
 }
 @SubscribeEvent public static void mineXp(BlockEvent.BreakEvent event) {
   if(event.getPlayer() instanceof ServerPlayer p && PlayerProgression.race(p).orElse(null)==Race.DEMON && !event.getState().isAir()) PlayerProgression.demonTask(p,"mining",2);
 }
}
