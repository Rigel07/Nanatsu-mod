package com.eric.nanatsuchaos.loot;

import com.eric.nanatsuchaos.NanatsuChaos;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import com.mojang.serialization.Codec;

public final class ChaosLootModifiers {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, NanatsuChaos.MOD_ID);
    public static final RegistryObject<Codec<ChaosChestFragmentModifier>> CHAOS_FRAGMENT =
            SERIALIZERS.register("chaos_fragment_loot", () -> ChaosChestFragmentModifier.CODEC);
    private ChaosLootModifiers() {}
}
