# Roadmap

## Prototype foundation
- [x] Forge 1.20.1 project and GitHub Actions build workflow
- [x] Persistent race choice and passive racial effects
- [x] Persistent Chaos fragment milestones (one tier-I skill every 50 fragments)
- [x] Large Chaos skill concept catalogue and first wave of active handlers
- [x] Fragment drop sources: mob kills, mining, generated chest loot
- [x] Seven Sacred Treasure item registrations and ultra-rare loot rolls
- [x] Four Grace and ten Commandment item registrations, absorption, persistent effects
- [x] Demon King state when all ten Commandments have been absorbed
- [x] Excalibur first-discovery world flag and tier-II skill reward
- [x] Hawk companion prototype

## Next implementation waves
- [ ] Verify build in CI and repair any Forge/API errors
- [ ] Give every Chaos skill its own truly distinct active mechanic; remove placeholder/shared handlers
- [ ] Give each Sacred Treasure a unique right-click/attack ability and proper cooldowns
- [ ] Implement Cath Palug as exactly one persistent world entity; cute companion state before Excalibur, boss state after first Excalibur discovery
- [ ] Restrict Cath Palug damage to Excalibur or Chaos abilities and add multi-phase boss attacks
- [ ] Add Grace and Commandment-specific abilities/rules, not only passive effects
- [ ] Add custom Hawk model/animations and patrol center/radius commands
- [ ] Add race-selection GUI and network synchronization
- [ ] Add Liones, Boar Hat, Fairy King's Forest biome, Sin statues and themed structures
- [ ] Add custom NPCs, enemy mobs, spawn rules, structure loot and world-generation tests
- [ ] Add models/textures/audio for every mob, weapon, structure and power

## v0.7.0 development update
- Replaced the seven Sacred Treasure placeholder items with `RelicWeaponItem` instances.
- Each treasure now has an independent right-click active technique, visual effects, target selection and individual cooldown: Lostvayne evasive Counter-Vanish, Rita solar blast, Courechouse pull, Herritt debuff/vision, Aldan suspension/resistance, Chastiefol healing/barrier, Gideon seismic slam.
- These are first playable implementations using vanilla Forge/Minecraft effects; custom 3D models, dedicated animations, durability balancing and in-game testing remain future work.


## v0.8.0 progress
- [x] Add server-side cast handlers for every current Chaos catalogue entry (89 IDs total).
- [x] Add saved Hawk patrol radius and center, with follow/stay/patrol commands.
- [x] Remove duplicate `ChaosWorldData` method declaration.
- [ ] Verify the actual Forge 1.20.1 compilation in CI.
- [ ] Add custom structure/biome world generation for Liones, Boar Hat, Fairy King's Forest, and Sin shrines.
- [ ] Add a graphical first-join race selection screen and custom mob models/animations.


## v0.9.0 progress
- [x] Add an in-game five-race selection screen opened by the R key; server-side choice remains permanent.
- [x] Add distinct active abilities for all four Graces and ten Commandments, with cooldowns.
- [x] Add rare chunk-load landmark prototypes for Liones, Boar Hat, Sin shrines and a Fairy King grove.
- [ ] Convert landmark prototypes into registered worldgen structures with loot tables and biome placement.
- [ ] Register a true Fairy King's Forest biome and connect structure placement to biome tags.
- [ ] Add first-join server-to-client sync so the race screen can open automatically only when a player has not chosen a race.
- [ ] Verify build in GitHub Actions and test in a dedicated Forge 1.20.1 world.


## v0.10.0
- Added loot chests to exploration landmarks with Chaos fragments and rare relic/weapon rolls.
- Still pending: run a real ForgeGradle build and in-game smoke test; replace chunk-load prototypes with registered configured/placed structures.


## v0.11.0
- Replaced chunk-load landmark construction with data-driven jigsaw structures and NBT templates.
- Added dedicated chest loot tables and separate rarity rolls for powers, sacred treasures, and Excalibur.
- Next: test structure placement in a fresh world, tune biome selectors, add more varied pieces/pools, and confirm all loot IDs against registered items.


## v0.12.0 worldgen follow-up
- [x] Expand the existing four landmark templates.
- [x] Add four more themed structures and loot tables.
- [x] Add Fairy Forest, Demon Realm and Goddess Highlands biome data definitions.
- [ ] Integrate the custom biomes into natural Overworld climate selection (biome-source integration).
- [ ] Run ForgeGradle build and verify structure generation in a fresh world.


## v0.12.0 worldgen follow-up
- [x] Expand the existing four landmark templates.
- [x] Add four more themed structures and loot tables.
- [x] Add Fairy Forest, Demon Realm and Goddess Highlands biome data definitions.
- [ ] Integrate the custom biomes into natural Overworld climate selection (biome-source integration).
- [ ] Run ForgeGradle build and verify structure generation in a fresh world.


## v0.13.0 — climate integration
- TerraBlender-backed Overworld region registration for the three Nanatsu Chaos biomes.
- Natural vegetation and ore features in the custom biomes.
- Themed structures allowed in their matching biomes.
- Requires TerraBlender Forge 1.20.1 as an additional mod dependency.
- Still pending: CI build result and actual in-game biome/structure distribution test.

## v0.14.0 — Balance de las Gracias
- Sunshine se refuerza como la Gracia más poderosa, con objetivo de equivalencia de combate de ocho Mandamientos.
- Flash, Ocean y Wind reciben mejoras pasivas y técnicas activas de nivel legendario, con objetivo de equivalencia de al menos tres Mandamientos cada una.
- Sunshine tiene un enfriamiento de 30 segundos; las otras técnicas mantienen 20 segundos.
- Pendiente: compilar con ForgeGradle y ajustar el balance mediante pruebas reales contra mobs fuertes y jugadores.
