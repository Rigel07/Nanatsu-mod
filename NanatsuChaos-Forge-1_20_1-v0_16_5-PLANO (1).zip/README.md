# Nanatsu Chaos — Forge 1.20.1

Fan-made fantasy adventure mod project inspired by *The Seven Deadly Sins*. Target: Minecraft 1.20.1, Forge 47.3.0, Java 17.

## Build

Sube este `.zip` **sin descomprimir** a un repositorio de GitHub junto con `.github/workflows/build.yml`
(el archivo viene dentro del zip). GitHub descomprime el zip, compila con Gradle 8.1.1 / JDK 17 y deja el
`.jar` en **Actions -> ultimo run -> Artifacts -> mod-jars**.

Requisito para jugar: **Forge 1.20.1 (47.3.0+)** y **TerraBlender 3.0.1.7 o superior (Forge 1.20.1)** en la carpeta `mods`.

## v0.16.1 - correcciones de compilacion y datos

- `build.gradle`: faltaban `minecraft_version_range`, `forge_version_range` y `loader_version_range` en `processResources` (el build fallaba al expandir `mods.toml`); se anade `reobfJar` para que el jar funcione fuera del entorno de desarrollo.
- `HawkEntity` / `CathPalugEntity`: implementan `getBreedOffspring`, `mobInteract` devuelve `InteractionResult`, `canBeLeashed(Player)` y atributos con `Mob.createMobAttributes()` (sin ellos el ataque cuerpo a cuerpo crasheaba por falta de `ATTACK_KNOCKBACK`).
- Huevo de Hawk con `ForgeSpawnEggItem` (registro diferido seguro).
- Biomas: formato 1.20.1 (`has_precipitation`), se quitan `minecraft:patch_snow` (no existe) y orden de features que podia provocar *Feature order cycle*.
- `global_loot_modifiers.json`: `entries` es una lista de ids, no de objetos; el modificador ahora solo actua en cofres (`chests/`).
- Plantillas `.nbt` de estructuras comprimidas con gzip (Minecraft no lee NBT sin comprimir).
- Pestana creativa "Nanatsu Chaos" con todos los objetos.

## Current implemented systems

- Player-persistent race selection via `/nanatsu race human|giant|demon|fairy|goddess` and distinct passive effects.
- Persistent Chaos fragment counter. Every 50 fragments absorbed awards one random, previously unowned tier-I skill, up to 50 tier-I skills.
- Chaos skill catalogue with tier-I concepts plus separate Excalibur and Cath Palug tier entries. `/nanatsu catalog`, `/nanatsu skills`, `/nanatsu cast <id>`, `/nanatsu progress`.
- Rare fragment drops from creature kills, mining, and generated chest loot.
- Very rare Sacred Treasures, Commandments, Graces and Excalibur loot rolls.
- Four Grace relics and ten Commandment relics. Right-click to absorb a relic; each one is unique per player. Their effects persist and are applied server-side. Absorbing all ten Commandments unlocks a powerful Demon King state.
- **Exclusive Grace/Commandment paths:** a player may follow the Four Graces path or the Ten Commandments path, never both at once. Individual Graces are intentionally extremely powerful. Renouncing a path removes all powers from that path and allows the player to absorb the other category.
- Excalibur's first discovery is stored globally in world saved data and unlocks a tier-II Chaos skill for the finder.
- Hawk tameable companion prototype: comic pig sounds, eats offered items, follows owner, can sit, attacks modestly and is invulnerable.
- Item models, simple pixel-art item icons, Spanish and English language keys.
- Client race-selection screen opened with the R key; the server still validates and permanently locks the first selected race.
- Active techniques for each absorbed Grace and Commandment via `/nanatsu power <id>`, each with its own cooldown.
- Rare deterministic exploration landmarks built on chunk load: a small Liones fortress, Boar Hat-style inn, Sin shrine, and Fairy King grove. These are prototypes built from vanilla blocks, not full custom structure templates or a registered biome.

## v0.15.0 — Gracia del Viento: barrera cortante

- La técnica `/nanatsu power grace_tornado` activa una barrera de viento durante 15 segundos.
- Mientras está activa, cancela el daño recibido por el jugador; cuando un atacante le golpea, recibe un contraataque cortante y retroceso.
- La barrera genera un anillo visible de partículas y corta automáticamente a los mobs hostiles que se acercan, con daño periódico y empuje.
- La técnica inicial del Viento también hace más daño, lanza más lejos a los enemigos y potencia velocidad, salto, resistencia y regeneración.
- Validación: ZIP y recursos comprobados; compilación Forge e interacción en Minecraft aún pendientes.

## Current limitations

This is an active prototype (v0.9.0), not yet the complete anime-scale world. The current landmark generator is a lightweight prototype; the full registered Fairy King's Forest biome, detailed Liones and Boar Hat structures, dedicated NPCs, custom mob models/animations, and full boss phases still require implementation and in-game testing. The Chaos skill service now has an explicit server-side handler for every catalogue ID. Some mechanics use vanilla effects as pragmatic prototypes and still need balance and in-game testing; this is not a substitute for custom animations, VFX, and dedicated entities.

## Commands

- `/nanatsu race <human|giant|demon|fairy|goddess>` — select a race once.
- `/nanatsu progress` — show race, fragment count, skills, Graces and Commandments.
- `/nanatsu catalog` — list catalogue tiers.
- `/nanatsu renounce graces` — permanently relinquish all absorbed Graces and allow the Commandments path.
- `/nanatsu renounce commandments` — relinquish all Commandments and the Demon King state, allowing the Graces path.
- `/nanatsu skills` — show unlocked skills.
- `/nanatsu cast <skill_id>` — activate a supported unlocked skill.
- `/nanatsu power grace_sun` (or `grace_flash`, `grace_ocean`, `grace_tornado`) — activate an absorbed Grace technique.
- `/nanatsu power commandment_<id>` — activate an absorbed Commandment technique.
- Press **R** to open the race-selection screen; selecting a race remains permanent.

## Fragment progression

Fragments are accumulated, not spent. The 50th, 100th, 150th, etc. absorbed fragment awards a random tier-I skill. The player keeps their lifetime total, and the same tier-I skill will not be awarded twice. The cap is 50 tier-I skills from fragments.


## v0.6.0 — Cath Palug (primer hito jugable)
- Se añade una entidad global Cath Palug que solo se genera una vez por mundo, con aparición extremadamente rara durante exploración después del primer día.
- Antes de Excalibur puede ser domesticado como compañero y se le puede ordenar sentarse/seguir.
- Al recoger la primera Excalibur (no hace falta usarla), el Cath existente despierta y se vuelve hostil; no se teletransporta al jugador.
- El jefe tiene 900 puntos de vida, gran resistencia y solo recibe daño de Excalibur o habilidades registradas del Caos.
- Al derrotarlo, el mundo registra la victoria y el jugador que asesta el golpe recibe una habilidad de nivel III aleatoria.
- Comando `/nanatsu cath` para consultar el estado global del encuentro.

Nota: esta es una implementación de juego en progreso. El modelo visual actual usa modelos/texturas vanilla como placeholder; aún faltan el modelo Cath personalizado, la pantalla gráfica de razas, estructuras/biomas propios y probar una compilación real en Forge.

### v0.7.0 — Sacred Treasure techniques
The seven Sacred Treasures have separate right-click power prototypes and individual cooldowns. Lostvayne grants a brief evasive state; Rita creates a burning solar blast; Courechouse pulls and slows enemies; Herritt weakens and reveals nearby foes; Aldan levitates enemies while protecting its wielder; Chastiefol heals nearby allies and grants resistance; Gideon performs a seismic knockback strike. These are gameplay prototypes built from Minecraft effects and still require an actual Forge build and in-game balance pass.


### v0.8.0 — Chaos skill implementation and Hawk patrol
- Added active server-side effects for the remaining catalogue entries so all 89 listed Chaos skills have a handler, rather than falling through to the unimplemented message.
- Added Hawk patrol commands with a persistent patrol center and radius: `/nanatsu hawk patrol <4..128>`, `/nanatsu hawk follow`, and `/nanatsu hawk stay`. The closest owned Hawk within 32 blocks is controlled. The patrol center/radius persist when the entity is saved.
- Fixed a duplicate method declaration in world saved data and aligned the Gradle project version with this release.
- Validation limitation: this authoring environment has no Gradle executable or wrapper, so the project has not been compiled or launched in Minecraft here. GitHub Actions remains the build validation path.


## v0.9.0 — race UI, powers, exploration landmarks
- Added an in-game race selection screen opened with R, with five race buttons and server-side race-lock validation.
- Added active server-side techniques for all four Graces and all ten Commandments, with per-technique cooldowns and effects that differ by power.
- Added rare deterministic chunk-load landmarks: a small Liones-inspired fortress, a Boar Hat-style inn, Sin shrines, and a Fairy King grove. A lodestone marker prevents duplicate generation on chunk reload. These are intentionally lightweight vanilla-block prototypes, not yet full custom structure templates or a registered biome.
- Validation limitation: no local Gradle executable/wrapper is available in this authoring environment; run the GitHub Actions workflow to discover compile/runtime issues.


## v0.10.0 — recompensas de exploración
- Los santuarios, la posada, el puesto de Liones y el claro feérico pueden incluir un cofre de recompensa.
- Los cofres dan fragmentos del Caos y botín común; las reliquias, armas sagradas y Excalibur tienen probabilidades muy bajas.
- Los lugares siguen siendo prototipos construidos al cargar chunks, no estructuras registradas mediante el sistema nativo de worldgen de Forge.
- Validación de esta entrega: integridad del ZIP y revisión estática de recursos; la compilación/ejecución en Minecraft aún debe confirmarse en Gradle/GitHub Actions.


## v0.11.0 — Worldgen structures

Exploration landmarks now use Minecraft's data-driven worldgen registries (`worldgen/structure`, `structure_set`, `template_pool`) and structure templates rather than being built by a chunk-load event. Four structures are included: Liones keep, Boar Hat inn, Sin shrine and Fairy grove. Their spacing/separation settings make Liones rarer than the smaller landmarks. Structure chests use dedicated loot tables with fragments, common treasure, rare Grace/Commandment items, Sacred Treasures, and an exceptionally rare Excalibur roll. Existing worlds may not generate structures in chunks that were already explored; create a new world or explore fresh chunks to test.

Validation: JSON syntax and ZIP/NBT archive integrity are checked by the packaging script. A full ForgeGradle build and in-game test have not been performed in this environment.


## v0.12.0 — world generation expansion

- Rebuilt the eight structure templates as larger, themed builds with interiors, towers, bridges, altars, courtyards and loot chests.
- Added Demon Fortress, Goddess Sanctuary, Fairy King's Tree and Camelot Ruins, each with a distinct loot table and structure placement settings.
- Added three data-driven biome definitions: Fairy Forest, Demon Realm and Goddess Highlands. These biome definitions are available to the datapack registry and referenced by themed structure rules; **automatic natural biome distribution still needs a dedicated biome-source integration and is not claimed as finished**.
- Removed the old chunk-load landmark generator where present, so it cannot duplicate the registered structure system.

### Locate structures
Use `/locate structure nanatsuchaos:demon_fortress`, `/locate structure nanatsuchaos:goddess_sanctuary`, `/locate structure nanatsuchaos:fairy_king_tree` or `/locate structure nanatsuchaos:camelot_ruins`.

The NBT templates and JSON files are generated as data assets. A real ForgeGradle build and in-game worldgen test are still required before treating this version as release-tested.




## v0.13.0 — integración climática natural del Overworld

- Added TerraBlender Forge 1.20.1 integration (`3.0.1.7`) and registered `NanatsuOverworldRegion` during common setup. The Fairy Forest, Demon Realm and Goddess Highlands now participate in the Overworld climate/region selection rather than existing only as standalone biome data files.
- Added surface vegetation and ore placed features to the three biome definitions so they are not empty landscapes.
- Linked Fairy King's Tree and Fairy Grove to the Fairy Forest, Demon Fortress to the Demon Realm, and Goddess Sanctuary to the Goddess Highlands. Liones, Boar Hat, Camelot Ruins and Sin Shrine can also appear in selected themed biomes.
- **Dependency:** install TerraBlender Forge for Minecraft 1.20.1 alongside this mod. Existing worlds do not retroactively replace biomes in already-generated chunks; create a new world to test natural biome distribution.
- Useful checks: `/locate biome nanatsuchaos:fairy_forest`, `/locate biome nanatsuchaos:demon_realm`, `/locate biome nanatsuchaos:goddess_highlands`.

Validation: all JSON resources were parsed and the ZIP archive was checked. This environment still has no Gradle wrapper or installed Gradle executable, so a full ForgeGradle build and in-game test remain outstanding.

## v0.14.0 — Gracias de nivel legendario

Las cuatro Gracias dejan de ser mejoras menores y se equilibran como sendas individuales capaces de competir contra varios Mandamientos:

- **Sol / Sunshine — objetivo equivalente a 8 Mandamientos:** la Gracia más rota. Potencia ofensiva y defensiva permanente, más fuerza durante el día, regeneración, absorción y resistencia; su técnica activa hace una explosión solar de gran daño, quema y debilita a los enemigos. Enfriamiento de 30 s.
- **Destello / Flash — objetivo equivalente a 3 Mandamientos:** movilidad extrema, velocidad, salto, minería acelerada, resistencia y daño mejorado; la técnica permite una embestida, daña y ralentiza enemigos cercanos y otorga una ventana de combate veloz.
- **Océano / Ocean — objetivo equivalente a 3 Mandamientos:** regeneración, respiración acuática, poder de conducto y gran dominio bajo lluvia/agua; su técnica golpea y ralentiza en área, cura al usuario y mejora mucho su resistencia.
- **Viento / Wind (ID interno `tornado`) — objetivo equivalente a 3 Mandamientos:** movilidad aérea, saltos extremos, caída lenta, resistencia y daño aumentado en el aire; su técnica lanza a los enemigos, les inflige daño y mejora temporalmente el combate aéreo.

Las equivalencias son objetivos de diseño, no una conversión matemática exacta del sistema de combate. Los Mandamientos siguen siendo acumulables entre sí; el conjunto completo conserva el camino del Rey Demonio. Las Gracias y los Mandamientos siguen siendo caminos incompatibles.

**Uso:** `/nanatsu power grace_sun`, `/nanatsu power grace_flash`, `/nanatsu power grace_ocean` o `/nanatsu power grace_tornado` activa la técnica de la Gracia que ya hayas absorbido.

Validación de esta entrega: revisión estática y recursos empaquetados; no se ha podido ejecutar una compilación Forge ni probar en Minecraft desde este entorno.


## v0.16.0 — Documentos de raza y técnicas avanzadas
- Lostvayne: mantener botón derecho absorbe el daño recibido; al soltar libera un contraataque cuya potencia crece con el daño acumulado. Cada 100 puntos aumentan el nivel destructivo; la cantidad acumulada no tiene límite programado. La destrucción del terreno limita el radio y el número de bloques para evitar congelar servidores.
- Lostvayne genera tres ilusiones de combate que desaparecen al recibir daño.
- Demonios: progresión persistente de niveles I–III. XP de combate, minería y exploración; umbrales de 500 XP para nivel II y 2300 XP para nivel III.
- Nivel II desbloquea Marca Demoníaca; nivel III mejora la marca superior.
- Documentos raros: Nebulosa Oscura (demonio), Metal Pesado (gigante), Voluntad Indomable (humano), Dominio del Árbol Sagrado (hada) y Luz Purificadora (diosa). Se consumen al hacer clic izquierdo y el desbloqueo queda permanente.
- Activación: `/nanatsu power dark_nebula`, `heavy_metal`, `human_will`, `sacred_tree`, `purification` o `demon_mark`.
- Las técnicas requieren haber desbloqueado el documento y tener la raza correspondiente.
